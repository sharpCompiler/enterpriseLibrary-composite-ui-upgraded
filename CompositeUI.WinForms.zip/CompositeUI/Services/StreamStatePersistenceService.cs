//===============================================================================
// Microsoft patterns & practices
// CompositeUI Application Block (updated for .NET 9)
//===============================================================================

using System;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Text.Json;
using Microsoft.Practices.CompositeUI.Properties;

namespace Microsoft.Practices.CompositeUI.Services
{
    /// <summary>
    /// Implements simple file-based <see cref="IStatePersistenceService"/> that stores
    /// <see cref="State"/> data as JSON using <see cref="System.Text.Json.JsonSerializer"/>.
    /// If <see cref="UseCryptographyAttribute"/> is enabled, the serialized bytes are
    /// encrypted/decrypted via <see cref="ICryptographyService"/>.
    /// </summary>
    public abstract class StreamStatePersistenceService : IStatePersistenceService, IConfigurable
    {
        private bool useCryptography;
        private ICryptographyService? cryptoSvc;

        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            WriteIndented = false
            // Add converters if your State model needs them.
        };

        /// <summary>
        /// The <see cref="ICryptographyService"/> used to protect sensitive data.
        /// </summary>
        [ServiceDependency(Required = false)]
        public ICryptographyService CryptographyService
        {
            get
            {
                if (cryptoSvc == null)
                {
                    throw new StatePersistenceException(string.Format(
                        CultureInfo.CurrentCulture,
                        Properties.Resources.ServiceMissingExceptionMessage,
                        typeof(ICryptographyService),
                        GetType()));
                }

                return cryptoSvc;
            }
            set { cryptoSvc = value; }
        }

        /// <summary>
        /// Configuration attribute that can be passed to the <see cref="IConfigurable.Configure"/> implementation 
        /// on the service, to determine whether cryptography must be used for persistence. It must be a 
        /// key in the dictionary with the name <c>UseCryptography</c>.
        /// </summary>
        public const string UseCryptographyAttribute = "UseCryptography";

        /// <summary>
        /// Saves the <see cref="State"/> to the persistence storage.
        /// </summary>
        /// <param name="state">The <see cref="State"/> to store.</param>
        public void Save(State state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));

            try
            {
                // Always overwrite state when saving.
                if (Contains(state.ID))
                {
                    Remove(state.ID);
                }

                byte[] payload = JsonSerializer.SerializeToUtf8Bytes(state, JsonOptions);

                if (useCryptography)
                {
                    payload = CryptographyService.EncryptSymmetric(payload);
                }

                OpenStream(state.ID, stream =>
                {
                    stream.Write(payload, 0, payload.Length);
                    stream.Flush();
                });
            }
            catch (Exception ex)
            {
                throw new StatePersistenceException(
                    string.Format(CultureInfo.CurrentCulture, Resources.CannotSaveState, state.ID), ex);
            }
        }

        /// <summary>
        /// Retrieves the saved <see cref="State"/> from the persistence storage.
        /// </summary>
        /// <param name="id">The id of the <see cref="State"/> to retrieve.</param>
        /// <returns>The <see cref="State"/> instance created from the store.</returns>
        public State Load(string id)
        {
            if (!Contains(id))
            {
                throw new StatePersistenceException(string.Format(
                    CultureInfo.CurrentCulture, Resources.StateDoesNotExist, id));
            }

            try
            {
                byte[] data = Array.Empty<byte>(); // ensure initialization

                OpenStream(id, stream =>
                {
                    ThrowIfInvalidStream(stream);
                    using var ms = new MemoryStream();
                    stream.CopyTo(ms);
                    data = ms.ToArray();
                });

                if (useCryptography)
                {
                    data = CryptographyService.DecryptSymmetric(data);
                }

                var state = JsonSerializer.Deserialize<State>(data, JsonOptions);
                if (state == null)
                    throw new StatePersistenceException($"Deserialization produced null for state '{id}'.");

                return state;
            }
            catch (Exception ex)
            {
                throw new StatePersistenceException(
                    string.Format(CultureInfo.CurrentCulture, Resources.CannotLoadState, id), ex);
            }
        }


        /// <summary>
        /// Removes the <see cref="State"/> from the persistence storage.
        /// </summary>
        /// <param name="id">The id of the <see cref="State"/> to remove.</param>
        public void Remove(string id)
        {
            try
            {
                RemoveStream(id);
            }
            catch (Exception ex)
            {
                throw new StatePersistenceException(
                    string.Format(CultureInfo.CurrentCulture, Resources.CannotLoadState, id), ex);
            }
        }

        /// <summary>
        /// Checks if the persistence services has the <see cref="State"/> with the specified
        /// id in its storage.
        /// </summary>
        public abstract bool Contains(string id);

        private static void ThrowIfInvalidStream(Stream stm)
        {
            if (stm == null || !stm.CanRead)
            {
                throw new StatePersistenceException(Resources.InvalidStateStream);
            }
        }

        /// <summary>
        /// Removes the <see cref="State"/> from the persistence storage.
        /// </summary>
        public abstract void RemoveStream(string id);

        /// <summary>
        /// Retrieves the <see cref="Stream"/> to use as the storage for the <see cref="State"/>.
        /// </summary>
        protected abstract Stream GetStream(string id);

        /// <summary>
        /// Retrieves the <see cref="Stream"/> to use as the storage for the <see cref="State"/>, specifying whether the 
        /// stream should be disposed after usage.
        /// </summary>
        /// <param name="id">The identifier of the associated <see cref="State"/>.</param>
        /// <param name="shouldDispose">Indicates if the stream will be disposed after usage.</param>
        protected virtual Stream GetStream(string id, out bool shouldDispose)
        {
            shouldDispose = true;
            return GetStream(id);
        }

        /// <summary>
        /// Configures the service using the provided settings collection.
        /// </summary>
        public virtual void Configure(NameValueCollection settings)
        {
            if (settings == null) throw new ArgumentNullException(nameof(settings));

            var value = settings[UseCryptographyAttribute];
            if (!string.IsNullOrEmpty(value) &&
                !bool.TryParse(value, out useCryptography))
            {
                throw new StatePersistenceException(Resources.InvalidCryptographyValue);
            }
        }

        private void OpenStream(string stateId, Action<Stream> operation)
        {
            Stream? stream = null;
            var dispose = true;
            try
            {
                stream = GetStream(stateId, out dispose);
                ThrowIfInvalidStream(stream);
                operation(stream);
            }
            finally
            {
                if (dispose)
                {
                    stream?.Dispose();
                }
            }
        }
    }
}
