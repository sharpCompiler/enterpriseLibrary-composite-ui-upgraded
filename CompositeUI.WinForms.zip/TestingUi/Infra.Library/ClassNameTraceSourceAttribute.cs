﻿#nullable enable
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Microsoft.Practices.CompositeUI;

namespace Services
{

    internal sealed class ClassNameTraceSourceAttribute : TraceSourceAttribute
    {
        public ClassNameTraceSourceAttribute()
            : base(typeof(DependentModuleLoaderService).FullName)
        {
        }
    }
}

    
