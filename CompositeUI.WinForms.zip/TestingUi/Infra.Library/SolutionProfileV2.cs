﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace SolutionProfileV2
{

    public static class XmlValidationHelper
    {
        /// <summary>
        /// Validates the XML against an embedded XSD and deserializes to T.
        /// The XSD must be embedded in the same assembly as this helper.
        /// </summary>
        public static T DeserializeXML<T>(string xml, string xsdResourceName, string schemaUri)
        {
            var serializer = new XmlSerializer(typeof(T));

            using var reader = GetValidatingReader(xml, xsdResourceName, schemaUri);
            var result = (T)serializer.Deserialize(reader)!;
            return result;
        }

        /// <summary>
        /// Returns an XmlReader that validates the provided XML against an embedded XSD.
        /// </summary>
        public static XmlReader GetValidatingReader(string xml, string xsdResourceName, string schemaUri)
        {
            // 1) Locate XSD as embedded resource
            var asm = typeof(XmlValidationHelper).Assembly;
            var ns = typeof(XmlValidationHelper).Namespace ?? string.Empty;
            // Try "{Namespace}.{xsdResourceName}" first; fall back to any resource that ends with the file name
            var resourceName = $"{ns}.{xsdResourceName}";
            Stream? xsdStream = asm.GetManifestResourceStream(resourceName);

            if (xsdStream == null)
            {
                // Fallback: search by suffix so callers can pass just "SolutionProfileV2.xsd"
                foreach (var name in asm.GetManifestResourceNames())
                {
                    if (name.EndsWith("." + xsdResourceName, StringComparison.OrdinalIgnoreCase))
                    {
                        resourceName = name;
                        xsdStream = asm.GetManifestResourceStream(name);
                        break;
                    }
                }
            }

            if (xsdStream == null)
            {
                var available = string.Join(Environment.NewLine, asm.GetManifestResourceNames());
                throw new FileNotFoundException(
                    $"Embedded XSD '{xsdResourceName}' not found. " +
                    $"Tried '{resourceName}'. Available resources:{Environment.NewLine}{available}");
            }

            using var schemaReader = new XmlTextReader(xsdStream);

            // 2) Configure validating reader
            var settings = new XmlReaderSettings
            {
                ValidationType = ValidationType.Schema,
                DtdProcessing = DtdProcessing.Prohibit
            };

            settings.Schemas.Add(schemaUri, schemaReader);
            settings.ValidationEventHandler += static (sender, args) =>
            {
                // Treat any validation warning/error as fatal (mimics typical CAB behavior)
                throw new XmlSchemaValidationException(args.Message, args.Exception, args.Exception?.LineNumber ?? 0, args.Exception?.LinePosition ?? 0);
            };

            // 3) Create reader over the XML string with schema validation enabled
            var xmlStringReader = new StringReader(xml);
            return XmlReader.Create(xmlStringReader, settings);
        }
    }

    /// <summary>
    /// Root type for the v2 CAB profile.
    /// </summary>
    [XmlType(AnonymousType = true, Namespace = "http://schemas.microsoft.com/pag/cab-profile/2.0")]
    [XmlRoot("SolutionProfile", Namespace = "http://schemas.microsoft.com/pag/cab-profile/2.0", IsNullable = false)]
    public class SolutionProfileElement
    {
        /// <remarks>One or more sections.</remarks>
        [XmlElement("Section")]
        public SectionElement[] Section { get; set; }
    }

    /// <summary>
    /// A named section that contains dependencies and module entries.
    /// </summary>
    [XmlType(AnonymousType = true, Namespace = "http://schemas.microsoft.com/pag/cab-profile/2.0")]
    public class SectionElement
    {
        /// <remarks>Section-level dependencies on other sections.</remarks>
        [XmlArrayItem("Dependency", IsNullable = false)]
        public DependencyElement[] Dependencies { get; set; }

        /// <remarks>Modules that belong to this section.</remarks>
        [XmlArrayItem("ModuleInfo", IsNullable = false)]
        public ModuleInfoElement[] Modules { get; set; }

        /// <remarks>The section name.</remarks>
        [XmlAttribute]
        public string Name { get; set; }
    }

    /// <summary>
    /// A dependency entry (either at section-level or module-level).
    /// </summary>
    [XmlType(AnonymousType = true, Namespace = "http://schemas.microsoft.com/pag/cab-profile/2.0")]
    public class DependencyElement
    {
        [XmlAttribute]
        public string Name { get; set; }
    }

    /// <summary>
    /// A role entry allowed to load a module.
    /// </summary>
    [XmlType(AnonymousType = true, Namespace = "http://schemas.microsoft.com/pag/cab-profile/2.0")]
    public class RoleElement
    {
        [XmlAttribute]
        public string Allow { get; set; }
    }

    /// <summary>
    /// A module entry inside a section.
    /// </summary>
    [XmlType(AnonymousType = true, Namespace = "http://schemas.microsoft.com/pag/cab-profile/2.0")]
    public class ModuleInfoElement
    {
        /// <remarks>Optional per-module dependencies (some catalogs use section-level only).</remarks>
        [XmlArrayItem("Dependency", IsNullable = false)]
        public DependencyElement[] Dependencies { get; set; }

        /// <remarks>Optional role restrictions.</remarks>
        [XmlArrayItem("Role", IsNullable = false)]
        public RoleElement[] Roles { get; set; }

        /// <remarks>The DLL filename of the module.</remarks>
        [XmlAttribute]
        public string AssemblyFile { get; set; }

        /// <remarks>Optional friendly name.</remarks>
        [XmlAttribute]
        public string Name { get; set; }
    }
}
