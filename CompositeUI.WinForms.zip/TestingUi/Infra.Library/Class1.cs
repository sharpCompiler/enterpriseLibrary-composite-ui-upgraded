﻿//#nullable enable
//using Microsoft.Practices.CompositeUI;
//using Microsoft.Practices.CompositeUI.Configuration;
//using Microsoft.Practices.CompositeUI.Services;
//using Microsoft.Practices.CompositeUI.Utility;
//using Microsoft.Practices.ObjectBuilder;
//using System;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.Globalization;
//using System.IO;
//using System.Reflection;
//using System.Threading;
//using Walmart.Connexus.UI.Infrastructure.Module;

//namespace Services
//{
//    public class DependentModuleLoaderService : IModuleLoaderService
//    {
//        private readonly Dictionary<Assembly, ModuleMetadata> _loadedModules = new();
//        private readonly TraceSource? _traceSource;

//        [InjectionConstructor]
//        public DependentModuleLoaderService([ClassNameTraceSource] TraceSource traceSource)
//        {
//            _traceSource = traceSource;
//        }

//        public IList<LoadedModuleInfo> LoadedModules
//        {
//            get
//            {
//                var result = new List<LoadedModuleInfo>();
//                foreach (var md in _loadedModules.Values)
//                    result.Add(md.ToLoadedModuleInfo());
//                return result.AsReadOnly();
//            }
//        }

//        public event EventHandler<DataEventArgs<LoadedModuleInfo>> ModuleLoaded;

//        public void Load(WorkItem workItem, params IModuleInfo[] modules)
//        {
//            Guard.ArgumentNotNull(workItem, nameof(workItem));
//            Guard.ArgumentNotNull(modules, nameof(modules));
//            InnerLoad(workItem, modules);
//        }

//        public void Load(WorkItem workItem, params Assembly[] assemblies)
//        {
//            Guard.ArgumentNotNull(workItem, nameof(workItem));
//            Guard.ArgumentNotNull(assemblies, nameof(assemblies));

//            var list = new List<IModuleInfo>();
//            foreach (var asm in assemblies)
//                list.Add(new ModuleInfo(asm));

//            InnerLoad(workItem, list.ToArray());
//        }

//        protected virtual void OnModuleLoaded(LoadedModuleInfo loadedModule)
//            => ModuleLoaded?.Invoke(this, new DataEventArgs<LoadedModuleInfo>(loadedModule));

//        private void InnerLoad(WorkItem workItem, IModuleInfo[] modules)
//        {
//            if (modules.Length == 0) return;

//            var allowed = FilterModulesBasedOnRole(modules);
//            LoadAssemblies(allowed);

//            var loadOrder = GetLoadOrder();

//            foreach (var md in loadOrder)
//                md.LoadServices(workItem);

//            foreach (var md in loadOrder)
//                md.InitializeWorkItemExtensions(workItem);

//            foreach (var md in loadOrder)
//            {
//                if (!ContextManager.IsCancelled)
//                    md.InitializeModuleClasses(workItem);
//                else
//                    break;
//            }

//            foreach (var md in loadOrder)
//                md.NotifyOnLoadedModule(OnModuleLoaded);
//        }

//        private static IModuleInfo[] FilterModulesBasedOnRole(IModuleInfo[] modules)
//        {
//            var allowed = new List<IModuleInfo>();
//            foreach (var mi in modules)
//            {
//                if (mi.AllowedRoles.Count == 0)
//                {
//                    allowed.Add(mi);
//                }
//                else
//                {
//                    foreach (var role in mi.AllowedRoles)
//                    {
//                        if (Thread.CurrentPrincipal.IsInRole(role))
//                        {
//                            allowed.Add(mi);
//                            break;
//                        }
//                    }
//                }
//            }
//            return allowed.ToArray();
//        }

//        private List<ModuleMetadata> GetLoadOrder()
//        {
//            var indexed = new Dictionary<string, ModuleMetadata>(StringComparer.Ordinal);
//            var solver = new ModuleDependencySolver();
//            var result = new List<ModuleMetadata>();

//            foreach (var data in _loadedModules.Values)
//            {
//                if (indexed.ContainsKey(data.Name))
//                    throw new ModuleLoadException(string.Format(
//                        CultureInfo.CurrentCulture, Properties.Resources.DuplicatedModule, data.Name));

//                indexed.Add(data.Name, data);
//                solver.AddModule(data.Name);
//                foreach (var dep in data.Dependencies)
//                    solver.AddDependency(data.Name, dep);
//            }

//            if (solver.ModuleCount > 0)
//            {
//                var order = solver.Solve();
//                for (int i = 0; i < order.Length; i++)
//                    result.Add(indexed[order[i]]);
//            }

//            return result;
//        }

//        private void LoadAssemblies(IModuleInfo[] modules)
//        {
//            foreach (var mi in modules)
//            {
//                if (ContextManager.IsRxReports)
//                {
//                    if (!AssemblyBelongsToRxReports(mi.AssemblyFile.ToUpperInvariant()))
//                        continue;
//                }

//                GuardLegalAssemblyFile(mi);
//                var asm = LoadAssembly(mi.AssemblyFile);
//                if (!_loadedModules.ContainsKey(asm))
//                    _loadedModules.Add(asm, new ModuleMetadata(asm, _traceSource, mi));
//            }
//        }

//        private Assembly LoadAssembly(string assemblyFile)
//        {
//            Guard.ArgumentNotNullOrEmptyString(assemblyFile, nameof(assemblyFile));
//            assemblyFile = GetModulePath(assemblyFile);
//            var file = new FileInfo(assemblyFile);

//            try
//            {
//                var asm = Assembly.LoadFrom(file.FullName);
//                _traceSource?.TraceInformation(Properties.Resources.LogModuleAssemblyLoaded, file.FullName);
//                return asm;
//            }
//            catch (Exception ex)
//            {
//                throw new ModuleLoadException(assemblyFile, ex.Message, ex);
//            }
//        }

//        private static string GetModulePath(string assemblyFile)
//            => Path.IsPathRooted(assemblyFile)
//                ? assemblyFile
//                : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, assemblyFile);

//        private static bool AssemblyBelongsToRxReports(string asmUpper)
//            => asmUpper.Contains(".EXE", StringComparison.Ordinal) ||
//               asmUpper.Contains("LAYOUT", StringComparison.Ordinal) ||
//               asmUpper.Contains("WMLOGIN", StringComparison.Ordinal) ||
//               asmUpper.Contains("REPORTS", StringComparison.Ordinal) ||
//               asmUpper.Contains("PICKUP", StringComparison.Ordinal) ||
//               asmUpper.Contains("SERVICEPROXY", StringComparison.Ordinal) ||
//               asmUpper.Contains("TOOLS", StringComparison.Ordinal) ||
//               asmUpper.Contains("SEARCH", StringComparison.Ordinal);

//        private void GuardLegalAssemblyFile(IModuleInfo modInfo)
//        {
//            Guard.ArgumentNotNull(modInfo, nameof(modInfo));
//            Guard.ArgumentNotNull(modInfo.AssemblyFile, "modInfo.AssemblyFile");

//            var path = GetModulePath(modInfo.AssemblyFile);
//            if (!File.Exists(path))
//                throw new ModuleLoadException(string.Format(
//                    CultureInfo.CurrentCulture, Properties.Resources.ModuleNotFound, path));
//        }

//        // ===================== Helper classes =====================

//        private sealed class ModuleMetadata
//        {
//            private readonly Assembly _assembly;
//            private readonly TraceSource? _traceSource;

//            private bool _loadedServices;
//            private bool _modulesInitialized;
//            private bool _extensionsInitialized;
//            private bool _notified;
//            private string? _name;

//            private readonly List<string> _dependencies = new();
//            private readonly List<Type> _moduleTypes = new();
//            private readonly List<IModule> _moduleClasses = new();
//            private readonly List<string> _roles = new();
//            private readonly List<ServiceMetadata> _services = new();
//            private readonly List<KeyValuePair<Type, Type>> _workItemExtensions = new();
//            private readonly List<Type> _workItemRootExtensions = new();

//            public ModuleMetadata(Assembly assembly, TraceSource? traceSource, IModuleInfo moduleInfo)
//            {
//                _assembly = assembly;
//                _traceSource = traceSource;

//                if (moduleInfo is IDependentModuleInfo infoType)
//                {
//                    _name = infoType.Name;
//                    _dependencies.AddRange(infoType.Dependencies);
//                }
//                else
//                {
//                    foreach (ModuleAttribute attr in assembly.GetCustomAttributes(typeof(ModuleAttribute), true))
//                        _name = attr.Name;

//                    foreach (ModuleDependencyAttribute attr in assembly.GetCustomAttributes(typeof(ModuleDependencyAttribute), true))
//                        _dependencies.Add(attr.Name);
//                }

//                foreach (var type in assembly.GetExportedTypes())
//                {
//                    foreach (ServiceAttribute attr in type.GetCustomAttributes(typeof(ServiceAttribute), true))
//                    {
//                        var registrationType = attr.RegisterAs ?? type;
//                        _services.Add(new ServiceMetadata(type, registrationType, attr.AddOnDemand));
//                    }

//                    foreach (WorkItemExtensionAttribute attr in type.GetCustomAttributes(typeof(WorkItemExtensionAttribute), true))
//                        _workItemExtensions.Add(new KeyValuePair<Type, Type>(attr.WorkItemType, type));

//                    foreach (RootWorkItemExtensionAttribute _ in type.GetCustomAttributes(typeof(RootWorkItemExtensionAttribute), true))
//                        _workItemRootExtensions.Add(type);

//                    if (!type.IsAbstract && typeof(IModule).IsAssignableFrom(type))
//                        _moduleTypes.Add(type);
//                }
//            }

//            public IEnumerable<string> Dependencies => _dependencies;

//            public string Name
//            {
//                get => _name ??= _assembly.FullName ?? "Unknown";
//                set => _name = value;
//            }

//            public void LoadServices(WorkItem workItem)
//            {
//                if (_loadedServices) return;

//                _loadedServices = true;
//                EnsureModuleClassesExist(workItem);

//                try
//                {
//                    foreach (var moduleClass in _moduleClasses)
//                    {
//                        moduleClass.AddServices();
//                        _traceSource?.TraceInformation(Properties.Resources.AddServicesCalled, moduleClass);
//                    }

//                    foreach (var svc in _services)
//                    {
//                        if (svc.AddOnDemand)
//                        {
//                            workItem.Services.AddOnDemand(svc.InstanceType, svc.RegistrationType);
//                            _traceSource?.TraceInformation(Properties.Resources.ServiceAddedOnDemand, Name, svc.InstanceType);
//                        }
//                        else
//                        {
//                            workItem.Services.AddNew(svc.InstanceType, svc.RegistrationType);
//                            _traceSource?.TraceInformation(Properties.Resources.ServiceAdded, Name, svc.InstanceType);
//                        }
//                    }
//                }
//                catch (Exception ex)
//                {
//                    ThrowModuleLoadException(ex);
//                }
//            }

//            private void EnsureModuleClassesExist(WorkItem workItem)
//            {
//                if (_moduleClasses.Count == _moduleTypes.Count) return;

//                try
//                {
//                    foreach (var moduleType in _moduleTypes)
//                    {
//                        var moduleImpl = (IModule)workItem.Items.AddNew(moduleType);
//                        _moduleClasses.Add(moduleImpl);
//                        _traceSource?.TraceInformation(Properties.Resources.LogModuleAdded, moduleType);
//                    }
//                }
//                catch (FileNotFoundException ex)
//                {
//                    ThrowModuleReferenceException(ex);
//                }
//                catch (Exception ex)
//                {
//                    ThrowModuleLoadException(ex);
//                }
//            }

//            public void InitializeModuleClasses(WorkItem workItem)
//            {
//                if (_modulesInitialized) return;

//                _modulesInitialized = true;
//                EnsureModuleClassesExist(workItem);

//                try
//                {
//                    foreach (var moduleImpl in _moduleClasses)
//                    {
//                        moduleImpl.Load();
//                        _traceSource?.TraceInformation(Properties.Resources.ModuleStartCalled, moduleImpl);
//                    }
//                }
//                catch (FileNotFoundException ex)
//                {
//                    ThrowModuleReferenceException(ex);
//                }
//                catch (Exception ex)
//                {
//                    ThrowModuleLoadException(ex);
//                }
//            }

//            public void InitializeWorkItemExtensions(WorkItem workItem)
//            {
//                if (_extensionsInitialized) return;

//                _extensionsInitialized = true;

//                var svc = workItem.Services.Get<IWorkItemExtensionService>();
//                if (svc == null) return;

//                foreach (var kvp in _workItemExtensions)
//                    svc.RegisterExtension(kvp.Key, kvp.Value);

//                foreach (var type in _workItemRootExtensions)
//                    svc.RegisterRootExtension(type);
//            }

//            public void NotifyOnLoadedModule(Action<LoadedModuleInfo> action)
//            {
//                if (_notified) return;

//                _notified = true;
//                action(ToLoadedModuleInfo());
//            }

//            public LoadedModuleInfo ToLoadedModuleInfo()
//                => new(_assembly, Name, _roles, _dependencies);

//            private void ThrowModuleLoadException(Exception inner)
//                => throw new ModuleLoadException(Name, string.Format(
//                    CultureInfo.CurrentCulture, Properties.Resources.FailedToLoadModule, _assembly.FullName, inner.Message));

//            private void ThrowModuleReferenceException(Exception inner)
//                => throw new ModuleLoadException(Name, Properties.Resources.ReferencedAssemblyNotFound, inner);
//        }

//        private sealed class ServiceMetadata
//        {
//            public bool AddOnDemand;
//            public Type InstanceType;
//            public Type RegistrationType;

//            public ServiceMetadata(Type instanceType, Type registrationType, bool addOnDemand)
//            {
//                InstanceType = instanceType;
//                RegistrationType = registrationType;
//                AddOnDemand = addOnDemand;
//            }
//        }

//        private sealed class ClassNameTraceSourceAttribute : TraceSourceAttribute
//        {
//            public ClassNameTraceSourceAttribute() : base(typeof(DependentModuleLoaderService).FullName) { }
//        }
//    }
//}
