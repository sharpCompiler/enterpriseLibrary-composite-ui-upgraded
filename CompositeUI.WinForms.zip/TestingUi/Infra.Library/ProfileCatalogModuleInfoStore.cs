﻿using Infra.Library;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.Configuration;
using Microsoft.Practices.CompositeUI.Services;
using Microsoft.Practices.CompositeUI.SmartParts;
using SolutionProfileV2;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace Services;

public class WorkspaceLocatorService : IWorkspaceLocatorService
{
    public IWorkspace FindContainingWorkspace(WorkItem workItem, object smartPart)
    {
        while (workItem != null)
        {
            foreach (KeyValuePair<string, IWorkspace> namedWorkspace in workItem.Workspaces)
            {
                if (namedWorkspace.Value.SmartParts.Contains(smartPart))
                    return namedWorkspace.Value;
            }

            workItem = workItem.Parent;
        }

        return null;
    }
}

public interface IWorkspaceLocatorService
{
    IWorkspace? FindContainingWorkspace(WorkItem workItem, object smartPart);
}

public class ProfileCatalogModuleInfoStore : IModuleInfoStore
{
    private string _catalogFilePath;

    public ProfileCatalogModuleInfoStore()
    {
        _catalogFilePath = "ProfileCatalog.xml"; // default file
    }

    public string CatalogFilePath
    {
        get => _catalogFilePath;
        set
        {
            _catalogFilePath = value;
        }
    }

    public string GetModuleListXml()
    {
        try
        {
            return File.ReadAllText(_catalogFilePath);
        }
        catch
        {
            return null; // preserve old behavior
        }
    }
}

public class XmlStreamDependentModuleEnumerator : IModuleEnumerator
{
    private IModuleInfoStore _moduleInfoStore;

    [ServiceDependency]
    public IModuleInfoStore ModuleInfoStore
    {
        get => _moduleInfoStore;
        set => _moduleInfoStore = value;
    }

    public XmlStreamDependentModuleEnumerator()
    {
    }

    public IModuleInfo[] EnumerateModules()
    {
        string xml = _moduleInfoStore.GetModuleListXml();
        if (string.IsNullOrEmpty(xml))
        {
            return Array.Empty<DependentModuleInfo>();
        }

        var doc = new XmlDocument();
        doc.LoadXml(xml);

        switch (doc.DocumentElement.NamespaceURI)
        {
            case SolutionProfileV1Parser.CabProfileNamespace:
                return new SolutionProfileV1Parser().Parse(xml);

            case SolutionProfileV2Parser.CabProfileNamespace:
                return new SolutionProfileV2Parser().Parse(xml);

            default:
                throw new InvalidOperationException("Properties.Resources.InvalidSolutionProfileSchema");
        }
    }
}


public class SolutionProfileV2Parser : ISolutionProfileParser
{
    public const string CabProfileNamespace = "http://schemas.microsoft.com/pag/cab-profile/2.0";

    public IModuleInfo[] Parse(string xml)
    {
        var solution = XmlValidationHelper.DeserializeXML<SolutionProfileV2.SolutionProfileElement>(
            xml, "SolutionProfileV2.xsd", CabProfileNamespace);

        var dmis = new List<DependentModuleInfo>();

        if (solution.Section != null)
        {
            foreach (var section in solution.Section)
            {
                foreach (var moduleInfo in section.Modules)
                {
                    var dmi = new DependentModuleInfo(moduleInfo.AssemblyFile);

                    SetModuleName(moduleInfo, dmi);
                    SetModuleRoles(moduleInfo, dmi);
                    SetSectionDependencies(solution.Section, section, dmi);
                    SetModuleDependencies(moduleInfo, dmi);

                    dmis.Add(dmi);
                }
            }
        }

        return dmis.ToArray();
    }

    private static void SetSectionDependencies(IReadOnlyList<SolutionProfileV2.SectionElement> sections,
        SolutionProfileV2.SectionElement section,
        DependentModuleInfo dmi)
    {
        if (section.Dependencies == null) return;

        foreach (var dep in section.Dependencies)
        {
            bool dependentSectionFound = false;

            foreach (var sec in sections)
            {
                if (string.Equals(sec.Name, dep.Name, StringComparison.Ordinal))
                {
                    dependentSectionFound = true;

                    if (sec.Modules != null)
                    {
                        foreach (var moduleInfo in sec.Modules)
                        {
                            // In v2, these are other modules’ *names* (the VB code added Name)
                            dmi.Dependencies.Add(moduleInfo.Name);
                        }
                    }

                    break; // matched section
                }
            }

            if (!dependentSectionFound)
            {
                throw new InvalidOperationException(
                    string.Format("Properties.Resources.DependencyNotFound", section.Name, dep.Name));
            }
        }
    }

    private static void SetModuleName(SolutionProfileV2.ModuleInfoElement configModuleInfo,
        DependentModuleInfo resultModuleInfo)
    {
        // 1) If name provided in config, use it
        resultModuleInfo.Name = configModuleInfo.Name;

        // 2) If no name in config, try metadata (assembly-level)
        if (string.IsNullOrEmpty(resultModuleInfo.Name))
        {
            var metaName = ModuleMetadataReflectionHelper.GetModuleName(resultModuleInfo.AssemblyFile);
            if (!string.IsNullOrEmpty(metaName))
                resultModuleInfo.Name = metaName;
        }

        // 3) Still no name? Generate one
        if (string.IsNullOrEmpty(resultModuleInfo.Name))
        {
            resultModuleInfo.Name = Guid.NewGuid().ToString();
        }

        // Push the “true” name back to the object graph so we can find it later
        configModuleInfo.Name = resultModuleInfo.Name;
    }


    private static void SetModuleRoles(SolutionProfileV2.ModuleInfoElement moduleInfo, DependentModuleInfo dmi)
    {
        if (moduleInfo.Roles != null && moduleInfo.Roles.Length > 0)
        {
            foreach (var role in moduleInfo.Roles)
            {
                dmi.AddRoles(role.Allow);
            }
        }
    }

    private static void SetModuleDependencies(SolutionProfileV2.ModuleInfoElement moduleInfo,
        DependentModuleInfo dmi)
    {
        // If the module itself declares explicit dependencies, add them
        if (moduleInfo.Dependencies != null && moduleInfo.Dependencies.Length > 0)
        {
            foreach (var dep in moduleInfo.Dependencies)
            {
                dmi.Dependencies.Add(dep.Name);
            }
        }
    }
}

public interface ISolutionProfileParser
{
    IModuleInfo[] Parse(string xml);
}
public class SolutionProfileV1Parser : ISolutionProfileParser
{
    public const string CabProfileNamespace = "http://schemas.microsoft.com/pag/cab-profile";

    public IModuleInfo[] Parse(string xml)
    {
        var solution =
            XmlValidationHelper.DeserializeXML<SolutionProfileV1.SolutionProfileElement>(
                xml, "SolutionProfileV1.xsd", CabProfileNamespace);

        var modules = new List<IModuleInfo>();

        if (solution.Modules != null)
        {
            foreach (var moduleInfo in solution.Modules)
            {
                var mi = new ModuleInfo(moduleInfo.AssemblyFile);
                SetModuleRoles(moduleInfo, mi);
                modules.Add(mi);
            }
        }

        return modules.ToArray();
    }

    private static void SetModuleRoles(
        SolutionProfileV1.ModuleInfoElement moduleInfo,
        ModuleInfo mi)
    {
        if (moduleInfo.Roles != null && moduleInfo.Roles.Length > 0)
        {
            foreach (var role in moduleInfo.Roles)
            {
                mi.AddRoles(role.Allow);
            }
        }
    }
}

public interface IDependentModuleInfo : IModuleInfo
{
    /// <summary>
    /// Gets the list of module names this module depends on.
    /// </summary>
    IList<string> Dependencies { get; }

    /// <summary>
    /// Gets the name of this module.
    /// </summary>
    string Name { get; }
}

public class DependentModuleInfo : ModuleInfo, IDependentModuleInfo
{
    private string _name;
    private readonly List<string> _dependencies = new();

    public DependentModuleInfo()
    {
    }

    public DependentModuleInfo(string assemblyFileName)
        : base(assemblyFileName)
    {
    }

    public IList<string> Dependencies => _dependencies;

    public string Name
    {
        get => _name;
        set => _name = value;
    }
}