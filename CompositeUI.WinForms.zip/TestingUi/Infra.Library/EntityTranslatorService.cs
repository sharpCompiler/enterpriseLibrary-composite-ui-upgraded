﻿#nullable enable
using System;
using System.Collections.Generic;
using Walmart.Connexus.UI.Infrastructure.Interface.Services;

namespace Services
{
    public class EntityTranslatorService : IEntityTranslatorService
    {
        private readonly List<IEntityTranslator> _translators = new();

        public void RegisterEntityTranslator(IEntityTranslator translator)
        {
            if (translator is null) throw new ArgumentNullException(nameof(translator));
            _translators.Add(translator);
        }

        public void RemoveEntityTranslator(IEntityTranslator translator)
        {
            if (translator is null) throw new ArgumentNullException(nameof(translator));
            _translators.Remove(translator);
        }

        public bool CanTranslate<TTarget, TSource>()
            => CanTranslate(typeof(TTarget), typeof(TSource));

        public bool CanTranslate(Type targetType, Type sourceType)
        {
            if (targetType is null) throw new ArgumentNullException(nameof(targetType));
            if (sourceType is null) throw new ArgumentNullException(nameof(sourceType));

            // NOTE: This mirrors the VB logic exactly (it returns true if NO translator is found).
            // If you intended the opposite, change 'FindTranslator(...) is null' to '!= null'.
            return IsArrayConversionPossible(targetType, sourceType)
                   || FindTranslator(targetType, sourceType) is null;
        }

        public TTarget Translate<TTarget>(object? source)
            => (TTarget)Translate(typeof(TTarget), source!);

        public object? Translate(Type targetType, object? source)
        {
            if (targetType is null) throw new ArgumentNullException(nameof(targetType));

            if (source is null)
            {
                // VB returns Nothing when target is an array; otherwise throws
                if (targetType.IsArray) return null;
                throw new ArgumentNullException(nameof(source));
            }

            var sourceType = source.GetType();

            if (IsArrayConversionPossible(targetType, sourceType))
            {
                return TranslateArray(targetType, source);
            }
            else
            {
                var translator = FindTranslator(targetType, sourceType);
                if (translator is not null)
                    return translator.Translate(this, targetType, source);
            }

            throw new EntityTranslatorException("No translator is available to perform the operation.");
        }

        // --- helpers ---

        private object TranslateArray(Type targetType, object source)
        {
            var targetItemType = targetType.GetElementType()!;
            var sourceArray = (Array)source;
            var result = (Array)Activator.CreateInstance(targetType, sourceArray.Length)!;

            for (int i = 0; i < sourceArray.Length; i++)
            {
                var value = sourceArray.GetValue(i);
                if (value is not null)
                {
                    result.SetValue(Translate(targetItemType, value), i);
                }
            }

            return result;
        }

        private bool IsArrayConversionPossible(Type targetType, Type sourceType)
        {
            if (targetType.IsArray && targetType.GetArrayRank() == 1 &&
                sourceType.IsArray && sourceType.GetArrayRank() == 1)
            {
                return CanTranslate(targetType.GetElementType()!, sourceType.GetElementType()!);
            }
            return false;
        }

        private IEntityTranslator? FindTranslator(Type targetType, Type sourceType)
        {
            foreach (var trans in _translators)
            {
                if (trans.CanTranslate(targetType, sourceType))
                    return trans;
            }
            return null;
        }
    }

    public class EntityTranslatorException : Exception
    {
        public EntityTranslatorException(string noTranslatorIsAvailableToPerformTheOperation)
        {
            //throw new NotImplementedException();
        }
    }
}
