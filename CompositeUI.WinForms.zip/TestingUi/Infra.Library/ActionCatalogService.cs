﻿#nullable enable
using System;
using System.Collections.Generic;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.Utility;
using Walmart.Connexus.UI.Infrastructure.Interface.Services;

namespace Services
{
    public class ActionCatalogService : IActionCatalogService
    {
        private readonly Dictionary<string, List<IActionCondition>> _specificActionConditions = new(StringComparer.Ordinal);
        private readonly List<IActionCondition> _generalActionConditions = new();
        private readonly Dictionary<string, ActionDelegate> _actionImplementations = new(StringComparer.Ordinal);

        public void RegisterSpecificCondition(string action, IActionCondition actionCondition)
        {
            Guard.ArgumentNotNullOrEmptyString(action, nameof(action));
            Guard.ArgumentNotNull(actionCondition, nameof(actionCondition));

            if (!_specificActionConditions.TryGetValue(action, out var conditions))
            {
                conditions = new List<IActionCondition>();
                _specificActionConditions.Add(action, conditions);
            }

            // prevent duplicate condition type for this action
            var newType = actionCondition.GetType();
            foreach (var condition in conditions)
            {
                if (condition.GetType() == newType)
                    throw new ActionCatalogException();
            }

            conditions.Add(actionCondition);
        }

        public void RegisterGeneralCondition(IActionCondition actionCondition)
        {
            Guard.ArgumentNotNull(actionCondition, nameof(actionCondition));

            var newType = actionCondition.GetType();
            foreach (var condition in _generalActionConditions)
            {
                if (condition.GetType() == newType)
                    throw new ActionCatalogException();
            }

            _generalActionConditions.Add(actionCondition);
        }

        public bool CanExecute(string action)
            => CanExecute(action, context: null, caller: null, target: null);

        public bool CanExecute(string action, WorkItem? context, object? caller, object? target)
        {
            Guard.ArgumentNotNullOrEmptyString(action, nameof(action));

            bool result = true;
            var pipeline = BuildActionConditionPipeline(action);

            foreach (var condition in pipeline)
                result = result && condition.CanExecute(action, context, caller, target);

            return result;
        }

        public void RemoveSpecificCondition(string action, IActionCondition actionCondition)
        {
            Guard.ArgumentNotNullOrEmptyString(action, nameof(action));
            Guard.ArgumentNotNull(actionCondition, nameof(actionCondition));

            if (_specificActionConditions.TryGetValue(action, out var conditions))
                conditions.Remove(actionCondition);
        }

        public void RemoveGeneralCondition(IActionCondition actionCondition)
        {
            Guard.ArgumentNotNull(actionCondition, nameof(actionCondition));
            _generalActionConditions.Remove(actionCondition);
        }

        public void RegisterActionImplementation(string action, ActionDelegate actionDelegate)
        {
            Guard.ArgumentNotNullOrEmptyString(action, nameof(action));
            Guard.ArgumentNotNull(actionDelegate, nameof(actionDelegate));

            _actionImplementations[action] = actionDelegate;
        }

        public void RemoveActionImplementation(string action)
        {
            Guard.ArgumentNotNullOrEmptyString(action, nameof(action));
            _actionImplementations.Remove(action);
        }

        public void Execute(string action, WorkItem? context, object? caller, object? target)
        {
            Guard.ArgumentNotNullOrEmptyString(action, nameof(action));

            if (CanExecute(action, context, caller, target) &&
                _actionImplementations.TryGetValue(action, out var actionDelegate))
            {
                actionDelegate(caller, target);
            }
        }

        // ---- helpers ----
        private List<IActionCondition> BuildActionConditionPipeline(string action)
        {
            var pipeline = new List<IActionCondition>(_generalActionConditions);

            if (_specificActionConditions.TryGetValue(action, out var conditions))
                pipeline.AddRange(conditions);

            return pipeline;
        }
    }

    public class ActionCatalogException : Exception
    {
    }
}
