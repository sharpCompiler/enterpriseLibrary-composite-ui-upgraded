﻿#region Import Statements

using Microsoft.Practices.CompositeUI.Commands;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

#endregion

namespace Walmart.Connexus.UI.Infrastructure.Module
{
    /// <summary>
    /// Gets or Sets the Properties values that are used globally
    /// </summary>
    /// <remarks></remarks>
    [CLSCompliant(false)]
    public class ContextManager
    {
        public static Hashtable Themes;
        public static Hashtable ThemeApplies;
        public static Hashtable ThemeNormal;

        private static bool _isAppVaultCalledViaNewThread;


        //Changes related to the InputErrors

        //This will contain the value if any RPH is currently logged in.

        //CDI Changes

        //End CDI Changes
        //Gets the value of Patient Notification Troubleshoot messages flag

        //This will contain the value of domain

        //feature flag  : Off = works the old way, no label printing

        //RR-Compliance   :Changes for Pharmacy Leaflet Large Print for Visually impaired patients

        //BaggingQueue changes  - START

        /// <summary>
        /// To Check if the PSE purchasing is cloud enabled at the store or not.
        /// </summary>
        /// <remarks>The key is </remarks>
        private static bool _IsCloudEnabledForPSE;

        /// <summary>
        /// To Check if the DOM purchasing is cloud enabled at the store or not.
        /// </summary>
        /// <remarks>Replaced app config settings (IsCloudEnabledForDOM) to flag (19247)</remarks>
        private static bool _isCloudEnabledForDOM;

        //BaggingQueue changes  - END
        //Brand Generic Pricing: Start - Added property to hold Pricing Error BU parm codes

        //Brand Generic Pricing: End

        //Billing project changes – Start – 08/28/12 – gbapatl
        //Billing project changes – End

        public static DialogResult _TPAInfoViewDialogResponse;

        //Brand Generic Profit Pricing Changes : Start | dgadiko | 10/08/2012

        //Brand Generic Profit Pricing Changes : Ends

        //Patient Safety Changes - Begin

        //Patient Safety changes - End

        //Cash Pay Restriction project changes – Start
        //Cash Pay Restriction project changes – End

        //Accurate Pricing Changes : Start | 10/01/2013

        //Accurate Pricing Changes : End

        //Patient Safety Iteration 2 changes - Begin

        //Patient Safety Iteration 2 changes end

        //R1-2014 patient safety changes start

        //R1-2014 patient safety changes end

        //ERx Phase II Changes - Adding a new property to check if it Multiple SPI is On/Off - Start

        //ERx Phase II Changes - Adding a new property to check if it Multiple SPI is On/Off - End

        //HIPAA electronic access project changes - start

        //HIPAA electronic access project changes â€“ end
        //Patient Safety R2 2014 changes start

        //Patient Safety R2 2014 changes end

        //Counseling Phase II - Start

        //Counseling Phase II - End
        // Accurate Pricing Drug Substitution Changes : Begin
        // Accurate Pricing Drug Substitution Changes : End

        //Counseling Phase 3 - Rx1403 changes - Start

        //Inventory Management Changes Start
        //Inventory Management Changes - End

        //Counseling Phase 3 - Rx1403 changes - End

        //HIPAA - Patient Linking and Merging changes - Start

        //HIPAA - Patient Linking and Merging changes - End
        //Compliance Change Start- Yellow log copy Elimination

        //Compliance Change End- Yellow log copy Elimination
        //Medavail Changes Start-Kiosk delivery option flag changes 

        //Patient Safety 1403  start changes
        //private static List<ProductBasicInfoBE> _ClozapineValues;

        //Express  checkout changes

        //RR- SinfoniaRx Changes
        private static string _StorePurpose;

        private static bool _IsElasticSearchEnabled;

        public static bool IsCentralFillOn { get; set; }

        public static bool IsCounselQueActive { get; set; }

        public static bool PNForceLocalUpdateFromCD { get; set; }

        public static bool EmerPharmacistRequired { get; set; }

        public static bool IsAppVaultCalledViaNewThread
        {
            get => _isAppVaultCalledViaNewThread;
            set
            {
                _isAppVaultCalledViaNewThread = value;
                //ACLContextManager.IsAppVaultCalledViaNewThread = _isAppVaultCalledViaNewThread;
            }
        }

        public static bool IsSigPadP2PEnabled { get; set; }

        public static bool RXPCSigPadAllowed { get; set; }

        public static bool Lane7000Enabled { get; set; }

        public static string PortToConnectToCDC { get; set; }

        public static bool RXPCSigPadEnabled { get; set; }

        public static bool FastMoversEnabled { get; set; }

        public static string PSEXmitProtocol { get; set; }

        public static bool IsInputErrorOn { get; set; }

        public static bool PrintRphCorrection { get; set; }

        public static bool PrintInputCorrection { get; set; }

        /// <summary>
        /// Specifies whether RxEodV3 is enabled or not
        /// </summary>
        /// <remarks></remarks>
        public static bool IsRxEodLabelV3 { get; set; }

        public static bool isHideEODV3StatusCounts { get; set; }

        public static bool IsNewWorkFlowOn { get; set; }

        /// <summary>
        /// time to check for amount of log copy work due within 30 minutes
        /// </summary>
        /// <remarks></remarks>
        public static int CheckLogCopyWorkDueETA { get; set; }

        /// <summary>
        /// number of prescriptions that must be available before alerting rx staff of log copies that need processed
        /// </summary>
        /// <remarks></remarks>
        public static int MinLogCopyToNotify { get; set; }

        /// <summary>
        /// Tells wheather EOD workque is being worked by other associate
        /// </summary>
        /// <remarks></remarks>
        public static bool IsEODWorkQueInUse { get; set; }

        /// <summary>
        /// time set for how often workflow is checked for prescriptions due in filling
        /// </summary>
        /// <remarks></remarks>
        public static int CheckFillWorkDueETA { get; set; }

        /// <summary>
        /// # set before ready log copy number being displayed for current day and all previous days turns to yellow/red
        /// </summary>
        /// <remarks></remarks>
        public static int CurrentEODRxBeforeYellow { get; set; }

        /// <summary>
        /// # set before ready log copy number being displayed for current day and all previous days turns to yellow/red
        /// </summary>
        /// <remarks></remarks>
        public static int CurrentEODRxBeforeRed { get; set; }

        /// <summary>
        /// # set before ready log copy number being displayed for current day and all previous days turns to yellow/red
        /// </summary>
        /// <remarks></remarks>
        public static int OldEODRxBeforeYellow { get; set; }

        /// <summary>
        /// # set before ready log copy number being displayed for current day and all previous days turns to yellow/red
        /// </summary>
        /// <remarks></remarks>
        public static int OldEODRxBeforeRed { get; set; }

        /// <summary>
        /// Laser Printer for system generated RxImages - For Rx Streamline EOD
        /// </summary>
        /// <remarks></remarks>
        public static string SysGenRXImgPrinter { get; set; }

        /// <summary>
        /// Specifies whether Scan using pixtools is enabled or not.
        /// If True - Scanning will be performed using PixTools
        /// If False - Scanning will be performed using 21kScan.exe
        /// </summary>
        /// <remarks></remarks>
        public static bool IsScanUsingPixToolsEnabled { get; set; }

        public static bool ConnexusLockoutDisplayed { get; set; }

        public static bool ConnexusLockoutWarningDisplayed { get; set; }

        /// <summary>
        /// Patient Weight Age Restriction added as part of CDI project
        /// </summary>
        /// <remarks></remarks>
        public static int PatientWeightAgeRestriction { get; set; }

        /// <summary>
        /// Property which says whether to enabled send to input enabled or not , implemented as part of CDI project
        /// </summary>
        /// <remarks></remarks>
        public static bool IsFaxInputEnabled { get; set; }

        /// <summary>
        /// Property which sets the max age for validation checks when used
        /// </summary>
        /// <remarks></remarks>
        public static int PatientMaxAge => 150;

        /// <summary>
        /// Snap Cap Age Restriction added as part of CDI project
        /// </summary>
        /// <remarks></remarks>
        public static int SnapCapAgeRestriction { get; set; }

        /// <summary>
        /// Easy Pay Age Restriction added as part of CDI project
        /// </summary>
        /// <remarks></remarks>
        public static int EasyPayAgeRestriction { get; set; }

        /// <summary>
        /// Ready reminder Age Restriction added as part of CDI project
        /// </summary>
        /// <remarks></remarks>
        public static int ReadyReminderAgeRestriction { get; set; }

        /// <summary>
        /// To Capture the Navigation is from Orderdetail
        /// </summary>
        /// <remarks></remarks>
        public static bool ShowOrderDetail { get; set; }

        /// <summary>
        /// To Capture the Navigation is from Orderdetail
        /// </summary>
        /// <remarks></remarks>
        public static bool IsCDIFlow { get; set; }

        /// <summary>
        /// To check whether CDI enabled for the store
        /// </summary>
        /// <remarks></remarks>
        public static bool IsCDIEnabled { get; set; }

        /// <summary>
        /// To check whether central patient is enabled
        /// </summary>
        /// <remarks></remarks>
        public static bool CentralPatientFlag { get; set; }

        /// <summary>
        /// Hide delete button on third party screen
        /// </summary>
        /// <remarks></remarks>
        public static bool HideTpDeleteFlag { get; set; }

        /// <summary>
        /// Hide family member button
        /// </summary>
        /// <remarks></remarks>
        public static bool HideFamilyMemberFlag { get; set; }

        public static bool CalculatePromiseTime { get; set; }

        /// <summary>
        /// To get the Time Difference between system time and DB time
        /// </summary>
        /// <remarks></remarks>
        public static long TimeDifference { get; set; }

        /// <summary>
        /// returns True if Promise time is to be calculated and updated.
        /// </summary>
        /// <remarks>CDI added</remarks>
        public static bool IsPromiseTimeVisible { get; set; }

        /// <summary>
        /// Return True  if store is central fill
        /// </summary>
        /// <remarks>CDI-19.4 Changes</remarks>
        public static bool IsCentralFillStore { get; set; }

        public static bool IsVisualVerifyForceHighlighted { get; set; }

        /// <summary>
        /// To enable and disable the pop up in dropoff and input
        /// </summary>
        /// <remarks></remarks>
        public static bool IsPopUPEnabled { get; set; }

        /// <summary>
        /// To hold the waiting in pharmacy offset
        /// </summary>
        /// <remarks></remarks>
        public static int WaitingInPharmacy { get; set; }

        /// <summary>
        /// To hold the shopping in store offset
        /// </summary>
        /// <remarks></remarks>
        public static int ShoppingInStore { get; set; }

        public static bool IsTroubleshootNotificationOn { get; set; }

        public static string LoginDomainText { get; set; }

        public static bool ReturnToStockLabelPrint { get; set; }

        public static bool IsC2FivePointChangesEnabled { get; set; }

        /// <summary>
        /// Flag for  indicate if Leaflet should be printed in large font - for visually impaired patients
        /// </summary>
        /// <remarks></remarks>
        public static bool IsLargeFontOnLeafletFlagOn { get; set; }

        public static bool IsVVRackTerminalFlagOn { get; set; }

        public static int StopVVTime { get; set; }

        public static int AllowedVVRackNumbers { get; set; }


        public static bool IsCloudEnabledForPSE
        {
            get => _IsCloudEnabledForPSE;
            set
            {
                _IsCloudEnabledForPSE = value;
                //ACLContextManager.IsCloudEnabledForPse = _IsCloudEnabledForPSE;
            }
        }

        /// <summary>
        /// To Check if the DOM purchasing is cloud enabled at the store or not.
        /// </summary>
        /// <remarks>Replaced app config settings (IsCloudEnabledForDOM) to flag (19247)</remarks>
        public static bool IsCloudEnabledForDOM
        {
            get => _isCloudEnabledForDOM;
            set
            {
                _isCloudEnabledForDOM = value;
                //ACLContextManager.IsCloudEnabledForDOM = _isCloudEnabledForDOM;
            }
        }

        public static bool IsEZPayXRefEnabled { get; set; }

        /// <summary>
        /// Flag for TDC Immunization History
        /// </summary>
        /// <remarks>The key is 10927 in bu_phm_parm table</remarks>
        public static bool IsTDCImmunizationHistoryActive { get; set; }

        /// <summary>
        /// Flag to Hide/show Mail-out option in PMTS
        /// </summary>
        /// <remarks>The key is 27020 in bu_phm_parm table</remarks>
        public static bool IsMailOutEnabled { get; set; }

        /// <summary>
        /// Flag to introduce Terminal assigned as VV Rack
        /// </summary>
        /// <remarks>Added as part of Bagging Queue 3 project. The key is 8670 in bu_phm_parm table</remarks>
        public static bool IsVVRack { get; set; }

        public static int GetMaxBagNumber { get; set; }

        public static int GetMinBagNumber { get; set; }

        public static bool IsPricingErrorCheckEnabled { get; set; }

        public static bool IsPricingErrorLoggingEnabled { get; set; }

        public static bool IsBillingErrorFlagOn { get; set; }

        public static DialogResult TPAInfoViewDialogResponse
        {
            get => _TPAInfoViewDialogResponse;
            set => _TPAInfoViewDialogResponse = value;
        }

        /// <summary>
        /// Temporary Flag to skip barcode printing in STR
        /// </summary>
        /// <remarks></remarks>
        public static bool SkipSTRBarcode { get; set; }

        public static bool IsBrandGenericProfitPricingAdjustment { get; set; }

        public static bool DisableTSRoleFilter { get; set; }

        public static CommandStatus TSMenuStatus { get; set; }

        public static bool IsTSRoleBasedSecurityEnabled { get; set; }

        public static bool IsDrugStrengthReEntryEnabled { get; set; }

        //public static ReEntryAuditLevels ReEntryAuditLevel { get; set; }

        public static bool IsCashPayRestrictionFlagOn { get; set; }

        public static bool IsAccuratePricingFlagOn { get; set; }

        public static bool IsPediatricPatientDisplayEnabled { get; set; }

        public static bool IsDaysSupplyRoundingEnabled { get; set; }

        public static bool IsCentralFillRTS { get; set; }

        public static bool IsAutoPrintMedguideEnabled { get; set; }

        public static bool IsCentralDUREnabled { get; set; }

        public static bool IsPrintingMedguideAllowed { get; set; }

        public static bool IsMultipleSPIOn { get; set; }

        public static bool IsElectronicAccessFlagOn { get; set; }

        public static bool IsHIPAAPrintSig { get; set; }

        public static bool IsBatchingEnabled { get; set; }

        public static bool IsDrugNameReEntryEnabled { get; set; }

        public static bool IsDrugFormReEntryEnabled { get; set; }

        public static bool IsFactsAndComparisonEnabled { get; set; }

        public static bool IsDrugRouteReEntryEnabled { get; set; }

        public static bool IsCancelActionFromCouselScr { get; set; }

        public static bool IsDrugSubstitutionFlagOn { get; set; }

        public static bool IsSearchScreenLoaded { get; set; }

        public static bool IsCounselScreenLoaded { get; set; }

        public static bool IsCounselStation { get; set; }

        public static bool HideEzPayRadioButtons { get; set; }

        public static string isOnhndsNonDept38LckDn { get; set; }

        public static bool NewPatientRestrictFlag { get; set; }

        public static bool IsYellowLogCopyFlagOn { get; set; }

        public static bool IsKioskDeliveryEnabled { get; set; }

        //Medavail Changes End-Kiosk delivery option flag changes 
        //To enable/disable Kiosk dropoff dispense validation functionality on dropoff screen
        public static bool IsKioskDropOffEnabled { get; set; }

        //Medavail PrePack changes to show columns on Kiosk Reports
        public static bool IsPrePackKioskReportEnabled { get; set; }

        //public static List<ProductBasicInfoBE> ClozapineValues
        //{
        //    get => _ClozapineValues;
        //    set
        //    {
        //        _ClozapineValues = value;
        //        if (_ClozapineValues?.Count > 0)
        //        {
        //            var clozapineWBCANCValues = _ClozapineValues[0].RestrictTypeValue.Split(',');
        //            //RR- Patient Safety 1503  start changes
        //            if (clozapineWBCANCValues?.Length == 8)
        //            {
        //                FirstTimeMaxWBC = Convert.ToInt32(clozapineWBCANCValues[0]);
        //                MaxWBC = Convert.ToInt32(clozapineWBCANCValues[1]);
        //                MinWBC = Convert.ToInt32(clozapineWBCANCValues[2]);
        //                FirstTimeMaxANC = Convert.ToInt32(clozapineWBCANCValues[3]);
        //                MaxANC = Convert.ToInt32(clozapineWBCANCValues[4]);
        //                MinANC = Convert.ToInt32(clozapineWBCANCValues[5]);
        //                LabTestValidDays = Convert.ToInt32(clozapineWBCANCValues[6]);
        //                MaxLabTestValidDays = Convert.ToInt32(clozapineWBCANCValues[7]);
        //                //RR- Patient Safety 1503  end changes
        //            }
        //        }
        //    }
        //}

        //public static bool Is4ptIconCountDisabled { get; set; }

        //public static PharmacyHoursUE StoreHours { get; set; }

        /// <summary>
        /// Property to shut off DrCallIn if another priority is selected.
        /// </summary>
        /// <remarks></remarks>
        public static bool IsDrCallInSelected { get; set; }

        /// <summary>
        /// To check whether consolidated notes view flag is enabled
        /// </summary>
        /// <remarks></remarks>
        public static bool IsConsolidatedNotesEnabled { get; set; }

        public static int ConnectMode { get; set; }
        public static bool IsExpressPoll { get; set; }
        public static int ExpressPollInterval { get; set; }
        public static bool ExpressDriveThruMode { get; set; }
        public static string RetailId { get; set; }
        public static string TokenVersion { get; set; }
        public static string Mode { get; set; }
        public static string TerminalType { get; set; }
        public static string TransactionId { get; set; }

        public static bool IsPickUpLayoutLoaded { get; set; }

        //Express  checkout changes end
        public static int MinWBC { get; set; }

        public static int MaxWBC { get; set; }

        public static int MinANC { get; set; }

        public static int MaxANC { get; set; }

        public static int LabTestValidDays { get; set; }

        public static bool IsWelcomeCallResolutionEnabled { get; set; }

        public static bool IsSpecialtyPharmacyEnabled { get; set; }

        public static bool IsInitialAssessmentResolutionEnabled { get; set; }

        public static bool IsRxRescanEnabled { get; set; }

        public static bool IsBlackBoxEnabled { get; set; }

        // Local Fill RTS Changes : Begin
        public static bool IsLocalFillRTS { get; set; }
        // Local Fill RTS Changes : End

        //Rx compliance: Suboxone (XDEA) changes
        public static bool IsXDEANbrCaptureRequired { get; set; }

        //Refactoring Changes - User Activity Performance Logging
        public static bool IsTascoPerformanceLoggingEnabled { get; set; }

        public static bool IsPerformanceLoggingEnabled { get; set; }

        //Flag for NPI and State license check
        public static bool LicenseValidationFlag { get; set; }

        //Flag to check for prescriber web service call
        public static bool IsPrescriberWebServiceFlagOn { get; set; }

        //PPI changes - Start
        public static bool IsImmunizationsEnabled { get; set; }
        public static bool IsGPHEnabledForImmunizations { get; set; }
        public static int StandingOrderExpirationMonths { get; set; }
        public static int StandingOrderExpirationDays { get; set; }
        public static int RPhOrderExpirationMonths { get; set; }
        public static int RPhOrderExpirationDays { get; set; }
        public static int ServiceExpirationDays { get; set; }
        public static int ServiceRequestQuantity { get; set; }
        public static int ServiceRequestDAWCode { get; set; }
        public static bool AllowRphIssuedOrderDrugsForTechnician { get; set; }
        public static int ServiceEditAllowHours { get; set; }

        public static bool IsIMZEventsEnabled { get; set; }

        public static bool IsTascoPaymentViaPpiEnabled { get; set; }

        //PPI changes - End
        public static bool IsStandingOrderIMZSettingsEnabled { get; set; }
        public static bool IsRphIssuedIMZSettingsEnabled { get; set; }

        public static bool PharmacistInitialsRequired { get; set; }

        //RR- Patient Safety 1502  start changes
        public static int FirstTimeMaxWBC { get; set; }
        public static int FirstTimeMaxANC { get; set; }

        public static int MaxLabTestValidDays { get; set; }

        //RR- Patient Safety 1502  end changes
        //Prescriber Selection 1503 Changes -start
        public static bool IsPrescriberDeceasedFlagOn { get; set; }

        public static bool IsPrescribedAuthorityFlagOn { get; set; }

        //Prescriber Selection 1503 Changes -end
        public static bool IsPharmacyInsuranceBillingSequenceFlagOn { get; set; }

        //Governs if Auto refill is enabled in store or not.
        public static bool IsAutoRefillEnabled { get; set; }

        //PPI Event changes start
        public static int EventDateSelectRange { get; set; }
        public static int EventExpirationDays { get; set; }

        public static bool ImmunizationEventBilling { get; set; }

        //PPI Event changes end
        //RR- PDC Phase - II Change - start
        public static bool IsPortionOfDaysCoveredFlagOn { get; set; }
        //RR- PDC Phase - II Change - end

        //PI-Special Character Restriction
        public static bool IsPatientNameSpecialCharCheckFlagOn { get; set; }

        //Order Fulfillment changes - Begin
        public static bool IsNewSTR { get; set; }
        public static bool IsNewPatientLeaflet { get; set; }
        public static int OnlineCusThresholdFlag { get; set; }
        public static bool PMEmailFlag { get; set; }
        public static bool PrintDigitalDoc { get; set; }
        public static bool IsRefillPrintEnabled { get; set; }
        public static bool IsSTRReBillEnabled { get; set; }
        public static bool IsOnlinePrefService { get; set; }
        public static int HoursBeforeStoreClose { get; set; }
        public static bool IsCnxLockForC2Backcount { get; set; } = false;

        public static bool IsCnxLockedForRPhLicenseCapture { get; set; } = false;

        //Order Fulfillment changes - End
        public static bool ValidateAddress { get; set; }
        public static bool ValidateZip { get; set; }
        public static bool ValidateZipInput { get; set; }
        public static int ValidateZipDays { get; set; }

        public static bool AddressStandardizationInput { get; set; }

        //Inventory Management changes - start
        public static bool IsZippoEnabled { get; set; }
        //Inventory Management changes - end

        public static bool CombineErrorMsgs { get; set; }

        public static bool ConnectDuplex { get; set; }

        //Order creation changes - start
        public static bool IsOnHoldLogicEnabled { get; set; }

        public static bool IsKeyStrokeLogEnabled { get; set; }

        //Order creation changes - end
        public static bool IsPullReadyReminderFromCentralFlagOn { get; set; }

        public static bool IsAddressStandardizationEnabled { get; set; }

        public static bool IsTascoAddressStandardizationEnabled { get; set; }

        public static int ConfidenceScore { get; set; }

        //Update Priority change -Order Pick up PI5 SP1-
        public static bool IsUpdatePriorityInTascoEnabled { get; set; }

        //PatientMaintenance changes
        public static bool IsPatMaintenanceInTascoEnabled { get; set; }

        //Zipcode validation in TASCO
        public static bool ValidateTascoZipFlag { get; set; }

        //Inventory Management changes - start
        public static bool IsACQCostRestricted { get; set; }
        public static bool IsRTSRestricted { get; set; }

        public static DateTime CIIDigitalLogbookFlag { get; set; }

        //Inventory Management changes - end
        public static bool IsOneHourPickUpEnabled { get; set; }
        public static bool IsOnlinePharmacy { get; set; }
        public static bool IsOnlinePharmacyViewLoaded { get; set; }

        public static int ExpirationPeriod { get; set; }

        //On hold phase 2
        public static bool IsOnHoldPhase2LogicEnabled { get; set; }
        public static double OnHoldCuttOffValue { get; set; }
        public static double OnHoldInterceptValue { get; set; }
        public static double OnHoldPickUpPercentConstValue { get; set; }
        public static double OnHoldPatDueAmtConstValue { get; set; }
        public static double OnHoldDaysSupplyConstValue { get; set; }
        public static double OnHoldAutoFillConstValue { get; set; }
        public static double OnHoldDotComConstValue { get; set; }
        public static double OnHoldIvrConstValue { get; set; }
        public static double OnHoldERxConstValue { get; set; }
        public static double OnHoldThirdPartyConstValue { get; set; }
        public static double OnHoldNewAssociateConstValue { get; set; }
        public static double OnHoldCashFillConstValue { get; set; }
        //public static ScanDriver DocScanner { get; set; }
        public static bool IsPrescriptionAlertDisplay { get; set; }
        public static bool IsCheckoutCancelled { get; set; }

        //public static string StorePurpose
        //{
        //    get => _StorePurpose;
        //    set
        //    {
        //        _StorePurpose = value;
        //        ACLContextManager.CurrentEnvironment = _StorePurpose;
        //    }
        //}

        public static string StoreEnvironment { get; set; }

        public static bool IsResolutionMessagingEnabled { get; set; }
        public static bool AutoPopulateSig { get; set; }
        public static bool SkipScanBadge { get; set; }
        public static bool DoNotPullFaxFromHost { get; set; }
        public static string StoreState { get; set; }
        public static int StoreIssueAgencyCode { get; set; }

        //public static ImageReplaceableIO ImgRIO { get; set; }

        //Changes for hiding coverage
        public static bool HideCoverageType { get; set; }

        //Yearly Validation
        public static bool YearlyValidation { get; set; }

        public static DateTime YearlyValidationRollOut { get; set; }

        //PMS Redesign - Flag name for PMSRedesign
        public static bool IsPMSRedesign { get; set; }
        public static bool PopulateGRAsync { get; set; }
        public static bool IsPhysicalAddressReq { get; set; }
        public static bool SignDeviceAvail { get; set; }


        public static bool IsCentralHealthCarePlatform { get; set; }
        public static bool IsCentralHealthCarePlatformUp { get; set; }
        public static bool IsCPPLockModDetailsForTechAt4PT { get; set; }
        public static bool IsAutoCheckEnabled { get; set; }
        public static int CIICycleCountInterval { get; set; }
        public static int TimerForQrCode { get; set; }
        public static bool isRphLockedOut { get; set; }

        public static bool EnableOpioidCheckbox { get; set; }
        public static int ValidateDaysSupply { get; set; }
        public static bool InitialAcuteOpioid { get; set; }
        public static int ValidateOpioidDaysSupply { get; set; }
        public static int ValidateOpioidMME { get; set; }
        public static int PatientSearchThreshold { get; set; }
        public static bool IsPatientSearchRedesignEnabled { get; set; }
        public static bool IsEmergencyContactEnabled { get; set; }
        public static bool IsBCDRSGDEnabled { get; set; }
        public static bool CaptureCSIdAsIs { get; set; }
        public static bool CapturePSEIdAsIs { get; set; }

        /// <summary>
        /// To check whether AD Authentication flag is enabled
        /// </summary>
        /// <remarks></remarks>
        public static bool IsADAuthenticationEnabled { get; set; }

        public static bool IsNaloxonesEnabled { get; set; }
        public static bool IsNaloxonesStatePartnershipsStateEnabled { get; set; }
        public static bool IsNaloxonesStatePartnershipsStoreEnabled { get; set; }
        public static int NxStatePartnershipMaxQuantity { get; set; }
        public static bool IsStandingOrderNXSettingsEnabled { get; set; }
        public static bool IsRphIssuedNXSettingsEnabled { get; set; }
        public static bool IsStateIssuedStandingOrderNXSettingsEnabled { get; set; }
        public static bool IsStandingOrderNXStatePartnershipsSettingsEnabled { get; set; }
        public static bool IsRphIssuedNXStatePartnershipsSettingsEnabled { get; set; }
        public static bool IsStateIssuedStandingOrderNXStatePartnershipsSettingsEnabled { get; set; }
        public static bool IsPatientSearchAuditEnabled { get; set; }
        public static int NxStandingOrderExpirationMonths { get; set; }
        public static bool PrescriptionMsgEnrolment { get; set; }
        public static bool IsIMZCounselSuppression { get; set; }
        public static bool IsDeliveryInfoOnTpSigReport { get; set; }
        public static bool IsCMSPrintEnabledAtBagging { get; set; }
        public static bool IsCurbSidePickupEnabled { get; set; }
        public static bool IsDigitalPayment { get; set; }
        public static bool IsRphDiscretionAllowed { get; set; }
        public static bool IsRphDiscretionAllowedAfterRelSelect { get; set; }
        public static bool IsIDExpiredPopupAllowed { get; set; }

        public static bool IsSamsMobileWalletAllowed { get; set; }

        //CancelRx
        public static bool IsCancelRxEnabled { get; set; }
        public static bool IsWKEnabled { get; set; }
        public static bool iPledgeRMARestriction { get; set; }

        public static bool IsDLUpdateAllowedFromTasco { get; set; }

        //Clinical Services Changes : IMZ Optimization Properties
        public static bool IsIMZMobileAppEnabled { get; set; }
        public static bool IsAnnualCounselOffer { get; set; }
        public static bool IsConnexusSSOLogin { get; set; }
        public static int SSOThreshold { get; set; }
        public static bool IsUSP800Flag { get; set; }

        public static bool IsContactRedesign { get; set; }

        //MedSync Changes
        public static bool IsTMMSyncEnabled { get; set; }
        public static bool IsLandlineRecognition { get; set; }
        public static bool IsControlledSubInventoryFlagOn { get; set; }
        public static bool IsABNDigitalization { get; set; }
        public static bool IsSpanishABNDigitalization { get; set; }

        //HIPAA Centralization - Flag name for HIPAA Centralization
        public static bool IsHIPAACentralized { get; set; }

        public static bool IsStoringEnabled { get; set; }
        public static bool IsWMLockerEnabled { get; set; }
        public static bool IsMTRReportFlagOn { get; set; }

        //Drug API Changes - Flag name for Drug API Changes in Product Search
        public static bool EnableDrugApiCode { get; set; }
        public static bool IsImageLookupService { get; set; }
        public static bool IsCloudCentralFill { get; set; }
        public static bool IsMOCFPickUpTimeOverrideEnabled { get; set; }
        public static bool IsCloudCentralFillDrugSub { get; set; }
        public static bool IsRouteERxToCFEnabled { get; set; }
        public static string NonAPDegrees { get; set; }
        public static string NonAPState { get; set; }
        public static bool MaxDoseEnabled { get; set; }
        public static bool TimeMyMedsEnabled { get; set; }

        public static bool EnableDispenseMethodSelection { get; set; }
        public static bool IsOnDemandCounselEnabled { get; set; }
        public static bool IsTMMInTascoEnabled { get; set; }
        public static bool IsNoticeOfPrivacyPracticesPrintChangesEnabled { get; set; }
        public static bool IsCPRInsulinEnabled { get; set; }
        public static bool IsDisableDowntimeFlagEnabled { get; set; }
        public static bool IsEnablePrintButtonFlagOn { get; set; }
        public static bool IsIntegratedPickupCounselEnabled { get; set; }
        public static bool IsEnableOtherCoverageAndClarificationFieldsFlagOn { get; set; }

        public static bool IsMissingErxsReportFlagEnabled { get; set; }

        //Prescriber API Changes - Flag name for Prescriber API Changes in Prescriber Search
        public static bool EnablePrescriberApiCode { get; set; }

        //COVID IMZ Changes - Flag name for COVID Immunization Changes
        public static bool IsCOVIDImmunizationFlowEnabled { get; set; }

        public static bool IsZeroPayPrintingDisabled { get; set; }

        //Medavail Changes Start-StoreKioskId 
        public static int StoreKioskId { get; set; }

        //Medavail Changes End-StoreKioskId 
        public static bool InsulinFunctionalityEnabled { get; set; }
        public static bool GroupIdFunctionalityEnabled { get; set; }
        public static bool CompetitorTransfersFunctionalityEnabled { get; set; }
        public static bool IMZDaysSupplyCheckEnabled { get; set; }

        //ConnexUs Remediation flags
        public static bool IsWaitToSolveV2 { get; set; }

        public static bool IsLastActionTaken { get; set; }

        //ConnexUs Realtime benefits check
        public static bool IsCheckBenefits { get; set; }
        public static string VRXBillingSupportNbr { get; set; }
        public static bool IsVerifyRxEnabled { get; set; }
        public static bool IsTempOverrideEnabledForVerifyRx { get; set; }
        public static bool IsMOShippingAddressValidationEnabled { get; set; }

        //COVID IMZ settings screen Changes - Flag name for COVID Immunization setting screen
        public static bool IsCOVIDImmunizationSettingEnabled { get; set; }
        public static bool IsCovidCommercializationEnabled { get; set; }

        public static bool IsCOVIDDoseTypeEnabled { get; set; }

        //Scriptability flag
        public static bool ScriptAbilityApiCode { get; set; }
        public static bool IsCovidStandingOrderIMZRestrictionEnabled { get; set; }
        public static bool IsCovidRphIssuedIMZRestrictionEnabled { get; set; }

        public static bool IsNonCheckoutDocumentPrinterFlagEnabled { get; set; }

        //Cloud DropOff UI changes - Adding Date Of Birth Control : Start
        public static bool IsDobRequiredForPatientSearch { get; set; }

        //Cloud DropOff UI changes - Adding Date Of Birth Control : End
        public static bool EnableClockStatusCheckCloudAPI { get; set; }
        public static bool EnablePECheckForCommercialAndMedicareAB { get; set; }
        public static bool PatientSearchCloudAPIFlagForSearchFromToolbar { get; set; }

        public static bool IsTechAllowed2Administer { get; set; }

        //Hiding Mail Delivery : Start
        public static bool IsMailDeliveryDropOffEnabled { get; set; }

        //Hiding Mail Delivery : End
        public static bool IsSamsDeliveryEnhancementsEnabled { get; set; }
        public static bool IsDispenseMethodEligibilityCheckEnabled { get; set; }
        public static bool IsRxToGoDeliveryScreenEnabled { get; set; }
        public static bool IsRxToGoExpeditedOrdersEnabled { get; set; }
        public static bool IsRxToGoDeliveryScreenMenuEnabled { get; set; }
        public static bool IsRxToGoCurbsidePickupAndMedicaidEnabled { get; set; }
        public static bool IsRxToGoCurbsideOrdersEnabled { get; set; }
        public static bool IsRxToGoShippingOrdersEnabled { get; set; }
        public static bool IsRxToGoCloudDispenseRuleEnabled { get; set; }
        public static bool IsTPDiscountCardEnabled { get; set; }

        public static bool IsSAROEnabledForConnexusLogin { get; set; }

        //Store INV-ADJ flag
        public static bool IsStoreINVADJFlagEnabled { get; set; }

        //Store cloud print flag
        public static bool IsCSOSStoreCloudPrintingEnabled { get; set; }

        //Store flag for CSOS cloud calls
        public static bool CSOSCloudStoreFlag { get; set; }
        public static bool RxOneFillingEnabled { get; set; }
        public static bool RxOneRtsEnabled { get; set; }
        public static bool RxOneAutoDOOSEnabled { get; set; }
        public static bool InsurancePamphletPrintEnabled { get; set; }
        public static bool IsPatientMartEnabled { get; set; }
        public static bool IsTdcPatientHistoryEnabled { get; set; }
        public static bool IsSLESConnexusLoginEnabled { get; set; }
        public static bool IsPrintNoticeOfAppealRightsFlagEnabled { get; set; }
        public static Dictionary<string, string> AppVaultAuthKeyInfo { get; set; }
        public static bool IsSigServiceEnabled { get; set; }
        public static bool IsImzExternalizationFlagEnabled { get; set; }
        public static bool IsINVACSIReportStoreFlagEnabled { get; set; }
        public static bool PCPCounselingFlagEnabled { get; set; }
        public static bool IsSplitBillPriceFixFlagEnabled { get; set; }
        public static bool IsCOVIDTestKitSettingsEnabled { get; set; }
        public static bool IsActivityReportFlagEnabled { get; set; }
        public static bool IsManualERXFederatedSearchEnabled { get; set; }
        public static bool IsSamsClub { get; set; }
        public static bool IsDiagnosticTestSettingsEnabled { get; set; }

        public static bool IsPatientVisitSettingsEnabled { get; set; }

        //Store flag for WCB ACSI cloud Print calls
        public static bool IsINVACSICloudPrintFlag { get; set; }
        public static bool IsImmunizationDropOffEnabled { get; set; }
        public static bool IsLogiCoyFlag { get; set; }
        public static bool IsBambooHealthFlagEnabled { get; set; }
        public static bool IsStrandOptionEnabled { get; set; }
        public static bool IsGlobalClinicalServiceSettingsEnabled { get; set; }
        public static bool IsSonicNaloxoneSettingsEnabled { get; set; }

        public static bool IsErxTransferEnabled { get; set; }

        //public static bool IsElasticSearchEnabled
        //{
        //    get => _IsElasticSearchEnabled;
        //    set
        //    {
        //        _IsElasticSearchEnabled = value;
        //        ACLContextManager.IsElasticSearchEnabled = _IsElasticSearchEnabled;
        //    }
        //}

        /// <summary>
        /// To check whether to use patient phigo data.
        /// </summary>
        /// <remarks></remarks>
        public static bool PatientPhigo { get; set; }

        /// <summary>
        /// To check whether to use ticket item creation screen.
        /// </summary>
        /// <remarks></remarks>
        public static bool TicketCreateScreen { get; set; }

        public static bool IsPSERPhApproval { get; set; }

        //Cloud Call For Inventory Reports
        public static bool isInventoryCloudAPIEnabled { get; set; }
        public static bool IsFaxHybridEnabled { get; set; }

        public static bool IsOutcomesMTMEnabled { get; set; }

        public static bool IsRxDeliveryFeeEnabled { get; set; }

        public static bool IsDiscountCardBillingEnabled { get; set; }
        public static Dictionary<string, string> AppVaultAuthKeyInfoforDOM { get; set; }
        public static bool IsAutoFillEnrollmentEnabled { get; set; }
        public static bool IsAutoFillExpiredOutOfRefillEnabled { get; set; }
        public static bool IsReturnToInmarCloudFlagEnabled { get; set; }
        public static bool IsReturnsStoreUpdateFlagDisabled { get; set; }
        public static bool IsAutoRefillConsentCaptureUIEnabled { get; set; }
        public static bool IsEmergencyC2AutoCoverEnabled { get; set; }
        public static bool IsPresciberSearchByMidNameDegreeState { get; set; }
        public static bool IsAFEnrollmentStatusTrackingEnabled { get; set; }
        public static bool IsSoldFillWarningEnabled { get; set; }
        public static bool IsRxPdEnabled { get; set; }

        public static bool IsSimplifyTransferInCaptureEnabled { get; set; }

        public static bool IsDigitalRxEnabled { get; set; }
        public static bool IsHealthServicesPortalEnabled { get; set; }

        public static bool IsRefillMsgHistoryEnabled { get; set; }
        public static bool IsDigitalCompetitiveTransferV2Enabled { get; set; }

        public static bool IsAppVaultKeyLoadedForCloudRefund { get; set; }

        public static int DigitalCompetitiveXferPriorityTime { get; set; }
        public static bool IsM3PEnabled { get; set; }
        public static bool IsBillingDawOverrideEnabled { get; set; }
        public static int DayRangeForWcbReport { get; set; }
        public static bool IsDigitalCompetitiveTransferMultiRxV2Enabled { get; set; }
        public static bool IsManualMtrEnabled { get; set; }

        public static bool IsHandlePatientMaintenanceShippingExceptionsEnabled { get; set; }

        public static bool IsWelcomeCallResolutionChecked { get; set; }
        public static bool IsInitialAssessmentResolutionChecked { get; set; }
        public static bool IsInitialCounselCallResolutionChecked { get; set; }

        public static bool IsClinicalOpportunitiesEnabled { get; set; }
        public static bool IsCprInsuranceAutoSyncEnabled { get; set; }

        public static string MaxInfantAgeInMonths { get; set; }

        public static bool IsImageCaptureEnabledAtFilling { get; set; }

        public static bool IsInitialCounselCallResolutionEnabled { get; set; }

        public static bool IsReportFillingDiscrepanciesEnabled { get; set; }

        public static bool IsAPRequiredFromCentral(int degreeCode, string APDegrees)
        {
            if (!(degreeCode > 0)) return false;

            if (string.IsNullOrEmpty(APDegrees)) return false;

            var degrees = APDegrees.Split(',');
            foreach (var Item in degrees)
                if (Item.Equals(degreeCode.ToString()))
                    return true;

            return false;
        }

        ///// <summary>
        ///// Checks whether the precriber state is from the list of states where supervisory physician detail capture should be
        ///// disabled
        ///// </summary>
        ///// <param name="stateCode"></param>
        ///// <returns></returns>
        //public static bool IsNonAPState(string stateCode)
        //{
        //    using (new Tracer(ConnexusCommonConstants.ConnexusTracer))
        //    {
        //        if (!(string.IsNullOrEmpty(NonAPState) && string.IsNullOrEmpty(stateCode)))
        //        {
        //            var states = NonAPState.Split(',');
        //            if (Convert.ToBoolean(states?.Any(Item => Item.Contains(stateCode)))) return true;
        //        }

        //        return false;
        //    }
        //}

        #region Properties

        public static bool IsSplashClosed { get; set; }

        public static bool IsCancelled { get; set; }

        public static string FromDate { get; set; } = string.Empty;

        public static string ToDate { get; set; } = string.Empty;

        public static bool IsRxReports { get; set; }

        public static bool IsTascoMode { get; set; }

        public static bool IsTascoEnabled { get; set; }

        public static bool IsSearchOptimizedEnabled { get; set; }

        public static bool IsNewF6SearchEnabled { get; set; }

        public static bool IsCancelActionNotSpecified { get; set; }

        public static bool IsSetStatusMode { get; set; }

        public static bool IsEodMode { get; set; }

        public static bool IsReLogin { get; set; }

        public static int SiteId { get; set; }

        public static int FloaterSiteId { get; set; }

        //public static string ServerName
        //{
        //    get
        //    {
        //        var serverUri = LocalSiteACL.GetLastServerName().ToUpper();
        //        var endOfProtocol = serverUri.IndexOf("://") + 3;
        //        var startOfPort = serverUri.IndexOf(":", endOfProtocol + 1);
        //        if (endOfProtocol > 0 && startOfPort > 0)
        //            return serverUri.Substring(endOfProtocol, startOfPort - endOfProtocol).Substring(0, 6);

        //        return serverUri.Substring(0, 6);
        //    }
        //}

        public static string DisplayName { get; set; }

        private static string _TitleConnexus;

        //public static string TitleConnexus
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(_TitleConnexus)) _TitleConnexus = UICommonResources.TitleConnexus;

        //        return _TitleConnexus;
        //    }
        //    set => _TitleConnexus = value;
        //}

        private static string _NoScanner;

        //public static string NoScanner
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(_NoScanner)) _NoScanner = UICommonResources.ScannerNotDetected;

        //        return _NoScanner;
        //    }
        //    set => _NoScanner = value;
        //}

        public static bool IsQwertyKeyBoard { get; set; }

        private static int _DbSiteId;

        public static int DBSiteId
        {
            get => _DbSiteId;
            set
            {
                _DbSiteId = value;
                //LocalSiteACL.SetProxyContextManagerSiteId(value);
            }
        }

        public static int ReportsSiteId { get; set; }

        public static int AppSiteId
        {
            get
            {
                if (SiteId > 0) return SiteId;

                return DBSiteId;
            }
        }

        /// <summary>
        /// The id of the store for which the user is working.
        /// </summary>
        /// <returns>The id of the store for which the user is working.</returns>
        /// <remarks></remarks>
        public static int ActivitySiteId
        {
            get
            {
                if (IsRemoteTurnedOn) return RemoteSiteId;

                return AppSiteId;
            }
        }

        public static long SearchStartTime { get; set; }

        //Private Shared _ArcInstance As APMRemoteControlLib.ARCInterface
        //Public Shared Property ArcInstance() As APMRemoteControlLib.ARCInterface
        //    Get
        //        Return _ArcInstance
        //    End Get
        //    Set(ByVal value As APMRemoteControlLib.ARCInterface)
        //        _ArcInstance = value
        //    End Set
        //End Property

        private static bool _AllScannersDown;

        public static bool AllScannersDown
        {
            get
            {
                //if (IsTascoMode)
                //    //Return (CacheWrapper.GetBuPhmParamValue(UICommonConstants.ScannersDown).Equals("TRUE", StringComparison.InvariantCultureIgnoreCase))
                //    return Convert.ToBoolean(CacheWrapper.BUInfo.VolatileBuInfo.AllScannersDown);

                return _AllScannersDown;
            }
            set => _AllScannersDown = value;
        }

        public static bool TsTpReject { get; set; }

        public static bool IsPickUpLoaded { get; set; }

        public static bool TPPayment { get; set; }

        public static bool AllOtherTS { get; set; }

        public static bool CancelApp { get; set; }

        public static bool ContactDoctor { get; set; }

        public static bool ContactCustomer { get; set; }

        public static string CurrentServerName { get; set; }

        public static bool RorAutoForceQue { get; set; }

        public static bool IsAlreadyInvoked { get; set; }

        public static string SearchCriteria { get; set; }

        public static string RemoteCountryCode { get; set; }

        public static bool NdcChangeWarning { get; set; }

        public static bool IsStoreLockedOut { get; set; }

        public static string BtnLeft { get; set; }

        public static bool LogOffInvoked { get; set; }

        public static string HelpFile { get; set; }

        //public static bool IsStoreDriveThru
        //{
        //    get => Convert.ToBoolean(CacheWrapper.BUInfo.VolatileBuInfo.DriveThrough);
        //    set => CacheWrapper.BUInfo.VolatileBuInfo.DriveThrough = value.ToString();
        //}

        public static bool IsStoreLive { get; set; }

        public static bool IsEasyPayStore { get; set; }

        public static string LockOutMessage { get; set; }

        public static int C2LicensingAgency { get; set; }

        public static bool IsStoreSet4PartialFill { get; set; }

        public static bool IsInactivePrescRestrict { get; set; }

        public static bool IsPIEnabled { get; set; }

        public static bool IsEnterpriseInventoryEnabled { get; set; }

        public static bool IsStOrdTyp { get; set; }

        public static string SyncPI { get; set; }

        public static string AutOrdMeth { get; set; }

        public static bool IsStOrdProc { get; set; }

        public static bool IsEZPayUpdated { get; set; }

        public static bool IsMedEZEnabled { get; set; }

        public static string MedCareEnabled { get; set; }

        public static int RefCnslNewRxRule { get; set; }

        public static int RefCnslRefillRxRule { get; set; }

        public static int MinPickupDays { get; set; }

        public static int MaxPickupDays { get; set; }

        public static int MinPosDays { get; set; }

        public static int MaxPosDays { get; set; }

        public static bool IsRphLogonFirstTimeToday { get; set; }

        public static bool IsOfflineOption { get; set; }

        public static bool IsHLReqdForState { get; set; }

        public static bool IsRxPrint { get; set; }

        public static bool IsHipaaEnabled { get; set; }

        public static int DrugSubRqmt { get; set; }

        public static bool IsAREnabled { get; set; }

        public static bool IsStsEnabled { get; set; }

        public static bool IsCdDeaCheck { get; set; }

        public static bool IsLoggedOut { get; set; }

        public static bool IsNpi { get; set; }

        public static bool IsNpiHost { get; set; }

        public static bool IsSamsDrugOrdering { get; set; }

        public static bool IsPdxActive { get; set; }

        public static bool IsC2UnAppl { get; set; }

        public static bool IsOnHandsLockDown { get; set; }

        public static bool IsOnHandsOtcLockDown { get; set; }

        public static bool IsRorPerf { get; set; }

        public static bool IsLogCopyPrinter { get; set; }

        public static bool IsRxLogCopyEnabledForRxOne { get; set; }

        public static bool IsBCEnabled { get; set; }

        public static bool IsABEnabled { get; set; }

        public static bool IsMBEnabled { get; set; }

        public static string PendingC2TroubleshootMsg { get; set; }

        //public static List<GetPendingC2RxsBE> PendingRxs { get; set; }

        public static string ContactEmailAddress { get; set; }

        public static string ContactPerson { get; set; }

        public static bool IsBUEmergencyWorkQueueEnabled { get; set; }

        public static long StartTime { get; set; }

        public static long CompleteTime { get; set; }

        public static string StartStation { get; set; }

        public static string CompleteStation { get; set; }

        //public static ActivityTracer PerformanceTracer { get; set; }
        public static DateTime? PerformanceNonActivityStartTime { get; set; }

        public static string Printer { get; set; }

        public static bool IsDbl4PointChkStore { get; set; }

        public static bool IsRestrictionEnabled { get; set; }

        public static bool IsExpressCheckoutLoaded { get; set; }

        public static bool IsCDSearch { get; set; }

        public static string CurrentFormName { get; set; }

        public static int InitiateScore { get; set; }

        public static int InitiateMaxRec { get; set; }

        public static int InitiateScoreForMore { get; set; }

        public static int InitiateMaxRecForMore { get; set; }

        public static bool IsPatientLinkOn { get; set; }

        public static string LinkAuth { get; set; }

        public static int CicsRealTimeout { get; set; }

        public static bool IsCDUpdate { get; set; }

        public static int InitiateSearchScoreForFind { get; set; }

        public static int AddPatientInitiateScore { get; set; }

        public static int AddPatientInitiateScoreForMore { get; set; }

        public static short RefillLimit { get; set; }

        public static bool Is24HourWorkFlow { get; set; }

        public static bool IsTriplicateMny { get; set; }

        public static bool IsHighResRequired { get; set; }

        public static bool IsScanColorEnabled { get; set; }

        public static bool IsMailOrder { get; set; }

        /// <summary>
        /// DaysofSupply Enhancement
        /// </summary>
        /// <returns></returns>
        public static bool IsDOSEnhancementFlagEnabled { get; set; }

        /// <summary>
        /// Early fill Days Allowed for High Audit Risk Drugs
        /// </summary>
        /// <returns></returns>
        public static int HighAuditRiskDrugEarlyFillDaysAllowed { get; set; }

        /// <summary>
        /// MO modernization change
        /// </summary>
        /// <returns></returns>
        public static bool IsMOModernizationFlagEnabled { get; set; }


        /// <summary>
        /// MO Ship to address feature flag
        /// </summary>
        /// <returns></returns>
        public static bool IsMODefaultShipToAddressEnabled { get; set; }

        /// <summary>
        /// CPR Easy PAy Auto Sync
        /// </summary>
        /// <returns></returns>
        public static bool IsEasyPayCPRAutoSyncFlagEnabled { get; set; }

        /// <summary>
        /// Grouping Rx MO modernization change
        /// </summary>
        /// <returns></returns>
        public static bool IsMOGroupingRxFlagEnabled { get; set; }

        public static bool IsTpSupplyDisabledForOmnisysPlanEnabled { get; set; }

        /// <summary>
        /// Flag MO Validate Card change
        /// </summary>
        /// <returns></returns>
        public static bool IsMOValidateCardFlagEnabled { get; set; }

        /// <summary>
        /// Cloud Refund feature flag
        /// </summary>
        /// <returns>Boolean value of Cloud refund flag</returns>
        public static bool IsCloudRefundEnabled { get; set; }

        /// <summary>
        /// Store Refund feature flag
        /// </summary>
        /// <returns>Boolean value of Store refund flag</returns>
        public static bool IsRxPdStoreRefundEnabled { get; set; }

        public static bool IsTPReject { get; set; }

        public static bool IsPayment { get; set; }

        public static bool IsContactCustomer { get; set; }

        public static bool IsContactDR { get; set; }

        public static bool IsAllOtherTS { get; set; }

        public static bool IsPci { get; set; }

        public static bool IsPse { get; set; }

        public static bool IsDispRorInfo { get; set; }

        public static bool IsRorModDetail { get; set; }

        public static bool IsAllowMinimize { get; set; }

        public static bool IsDroppedOff { get; set; }

        public static bool IsContinueDropOff { get; set; }

        public static bool IsDropOffCheckWork { get; set; }

        public static bool IsSecondaryPBill { get; set; }

        public static bool IsRorAutoForce { get; set; }

        public static bool IsApmStore { get; set; }

        public static bool IsAbilityPseDLScan { get; set; }

        public static bool IsAbilityCsidDLScan { get; set; }

        public static bool IsDLDob { get; set; }

        public static bool IsDLGender { get; set; }

        public static bool IsDLAddress { get; set; }

        public static bool IsDlId { get; set; }

        public static bool IsInputWDateFocus { get; set; }

        public static bool IsPatientNotification { get; set; }

        public static bool CheckMedicalConditions { get; set; }

        public static bool PromptMedicalConditions { get; set; }

        public static string DateSelected { get; set; }

        public static DateTime? PromiseTime { get; set; }

        public static bool IsPromiseTime { get; set; }

        public static bool IsCancelApp { get; set; }

        //private static UserInfoUE _userInfoEntity;

        //public static UserInfoUE UserInfoEntity
        //{
        //    get => _userInfoEntity;
        //    set
        //    {
        //        _userInfoEntity = value;
        //        _userInfoEntity.UserInitialsText = GetInitials;
        //    }
        //}

        private static string _userID;

        //public static string UserId
        //{
        //    get
        //    {
        //        if (_userInfoEntity?.UserId != null &&
        //            (_userInfoEntity.UserId.Trim() ?? "") != "")
        //            return _userInfoEntity.UserId.Trim().ToUpper(CultureInfo.CurrentCulture);

        //        return string.Empty;
        //    }
        //}

        public static bool IsMultipleLanguageActive { get; set; }

        public static bool IsOnHandsOTLockedDown { get; set; }

        public static int StateDaysLimit { get; set; }

        public static string PendingC2TsMessage { get; set; }

        public static bool IsQA40Enabled { get; set; }

        public static bool IsStoreSetForEmergencyFill { get; set; }

        public static bool IsEarlyFD { get; set; }

        //public static List<PharmacyCodeInfoUE> GetBCDiscontinuedSource
        //{
        //    get
        //    {
        //        using (new Tracer(ConnexusCommonConstants.ConnexusTracer))
        //        {
        //            var getBCSourceReq = new BaseRequest
        //            {
        //                SiteID = SiteId
        //            };
        //            var SourceInfo = new List<PharmacyCodeInfoUE>();

        //            var getBCSourceRes = LocalSiteACL.GetBCDiscSource(getBCSourceReq);
        //            //					Dim source As new PharmacyCodeTextBE
        //            foreach (var source in getBCSourceRes.BCDiscSourceInfo)
        //                SourceInfo.Add(CommonMapper.ConvertTopharmacyCodeInfoUE(source));

        //            return SourceInfo;
        //        }
        //    }
        //}

        /// <summary>
        /// pharmacy self reset
        /// </summary>
        /// <remarks></remarks>
        public static bool PhmSelfReset { get; set; }

        public static bool ShortRefillLeafletUS { get; set; }

        /// <summary>
        /// Returns the initials of the string
        /// </summary>
        /// <returns>String with initials</returns>
        /// <remarks></remarks>
        //private static string GetInitials
        //{
        //    get
        //    {
        //        var inits = string.Empty;
        //        if (!string.IsNullOrEmpty(UserInfoEntity.UserDescription))
        //        {
        //            char[] charArray = { ' ' };
        //            var userDescr =
        //                UserInfoEntity.UserDescription.Split(charArray, StringSplitOptions.RemoveEmptyEntries);
        //            for (var i = 0; i < userDescr.Length; i++) inits += userDescr[i].Substring(0, 1);
        //        }

        //        return inits;
        //    }
        //}

        public static bool IsFaxCommentsEnabled { get; set; }

        public static bool IsEarlyRefillsCdEnabled { get; set; }

        public static bool IsCheckDurHighConflictsEnabled { get; set; }

        public static bool IsVerifyDawEnabled { get; set; }

        public static bool IsUrgentMessageShortCutEnabled { get; set; }

        public static bool IsPseDobVisible { get; set; }

        public static bool IsPsePhoneVisible { get; set; }

        public static bool IsPseAddressVisible { get; set; }

        public static bool IsPseDrivingLicenseIdVisible { get; set; }

        public static bool DAW1StateRestriction { get; set; }

        public static bool DAW1StateRestrictionForHardCopy { get; set; }

        /// <summary>
        /// Used to load all the menus related information from the MenuConfig.xml
        /// </summary>
        /// <remarks></remarks>
        public static Dictionary<string, string> MenuConfigInfo { get; set; }

        public static string BeaconZone { get; set; }
        public static string BeaconColor { get; set; }


        /// <summary>
        /// Used to load all the menus related information from the MsgStatusCodes.xml
        /// </summary>
        /// <remarks></remarks>
        public static Dictionary<string, string> MsgStatusCodes { get; set; }

        #endregion

        #region Properties Related to ROR

        public static Dictionary<string, string> WorkQueueSettings { get; set; }

        public static Dictionary<string, bool> WorkQueueState { get; set; }

        public static int RemoteSiteId { get; set; }

        public static bool IsRemoteTurnedOn { get; set; }

        public static string RemoteServer1 { get; set; }

        public static string RemoteServer2 { get; set; }

        public static bool IsFooterRequired { get; set; }

        #endregion

        #region Multiple DEA Changes

        public static bool IsMultipleDEA { get; set; }

        public static bool Is4ptHiddenInOrderSearch { get; set; }

        public static bool IsBaggingQueueEnabled { get; set; }

        public static bool IsBaggingQueuePatientSearch { get; set; }

        #endregion

        #region Multiple Location DEA Changes

        public static bool IsMultipleLocation { get; set; }

        public static bool IsResolutionForceHighlighted { get; set; }
        public static bool IsWebRorInternalReportEnabled { get; set; }

        #endregion
    }
}