﻿using System;
using System.IO;

namespace Services
{
    public interface IModuleInfoStore
    {
        string GetModuleListXml();
    }
}