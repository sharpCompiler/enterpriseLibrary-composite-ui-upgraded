﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;


namespace SolutionProfileV1
{
    /// <summary>
    /// Root element of a CAB v1 Solution Profile
    /// </summary>
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory("code")]
    [XmlType(AnonymousType = true, Namespace = "http://schemas.microsoft.com/pag/cab-profile")]
    [XmlRoot("SolutionProfile", Namespace = "http://schemas.microsoft.com/pag/cab-profile", IsNullable = false)]
    public partial class SolutionProfileElement
    {
        private ModuleInfoElement[] modulesField;

        [XmlArrayItem("ModuleInfo", IsNullable = false)]
        public ModuleInfoElement[] Modules
        {
            get => modulesField;
            set => modulesField = value;
        }
    }

    /// <summary>
    /// A module entry for v1 CAB profiles
    /// </summary>
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory("code")]
    [XmlType(AnonymousType = true, Namespace = "http://schemas.microsoft.com/pag/cab-profile")]
    public partial class ModuleInfoElement
    {
        private RoleElement[] rolesField;
        private string assemblyFileField;
        private string updateLocationField;

        [XmlArrayItem("Role", IsNullable = false)]
        public RoleElement[] Roles
        {
            get => rolesField;
            set => rolesField = value;
        }

        [XmlAttribute]
        public string AssemblyFile
        {
            get => assemblyFileField;
            set => assemblyFileField = value;
        }

        [XmlAttribute(DataType = "anyURI")]
        public string UpdateLocation
        {
            get => updateLocationField;
            set => updateLocationField = value;
        }
    }

    /// <summary>
    /// A role element that controls who can load a module
    /// </summary>
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory("code")]
    [XmlType(AnonymousType = true, Namespace = "http://schemas.microsoft.com/pag/cab-profile")]
    public partial class RoleElement
    {
        private string allowField;

        [XmlAttribute]
        public string Allow
        {
            get => allowField;
            set => allowField = value;
        }
    }
}
