﻿using Microsoft.Practices.CompositeUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Infra.Library
{
    public static class ModuleMetadataReflectionHelper
    {
        /// <summary>
        /// Resolve the module's friendly name from assembly-level [assembly: Module(Name=...)].
        /// </summary>
        public static string? GetModuleName(string assemblyFileName)
        {
            try
            {
                var asm = LoadAssembly(assemblyFileName);
                return GetModuleName(asm);
            }
            catch
            {
                return null;
            }
        }

        public static string? GetModuleName(Assembly asm)
        {
            // Look for p&p CAB's ModuleAttribute on the assembly
            foreach (var attrib in asm.GetCustomAttributes(typeof(ModuleAttribute), inherit: false).OfType<ModuleAttribute>())
            {
                return attrib.Name;
            }
            return null;
        }

        /// <summary>
        /// Return names from [assembly: ModuleDependency("OtherModuleName")] attributes.
        /// </summary>
        public static IList<string> GetModuleDependencies(string assemblyFileName)
        {
            try
            {
                var asm = LoadAssembly(assemblyFileName);
                return GetModuleDependencies(asm);
            }
            catch
            {
                return new List<string>();
            }
        }

        public static IList<string> GetModuleDependencies(Assembly asm)
        {
            var results = new List<string>();
            foreach (var attrib in asm.GetCustomAttributes(typeof(ModuleDependencyAttribute), inherit: false)
                                      .OfType<ModuleDependencyAttribute>())
            {
                if (!string.IsNullOrWhiteSpace(attrib.Name))
                    results.Add(attrib.Name!);
            }
            return results;
        }

        // --- helpers ---

        private static Assembly LoadAssembly(string assemblyFileName)
        {
            // Support relative filenames in catalogs; resolve next to the app
            var baseDir = AppContext.BaseDirectory;
            var fullPath = Path.IsPathRooted(assemblyFileName)
                ? assemblyFileName
                : Path.Combine(baseDir, assemblyFileName);

            fullPath = Path.GetFullPath(fullPath);

            // LoadFrom keeps probing for deps next to the loaded assembly,
            // which is what CAB-style module folders expect.
            return Assembly.LoadFrom(fullPath);
        }
    }
}
