﻿using System.Windows.Forms;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.Services;
using Microsoft.Practices.CompositeUI.WinForms;
using Services;
using Walmart.Connexus.UI.Infrastructure.Interface.Services;

namespace Infra.Layout
{
    public abstract class SmartClientApplication<TWorkItem, TShell>
        : FormShellApplication<TWorkItem, TShell>
        where TWorkItem : WorkItem, new()
        where TShell : Form
    {
        protected override void AddServices()
        {
            base.AddServices();

            var services = RootWorkItem.Services;

            // Core CAB services
            services.AddNew<ProfileCatalogModuleInfoStore, IModuleInfoStore>();
            services.AddNew<WorkspaceLocatorService, IWorkspaceLocatorService>();

            // Remove default enumerator/loader to plug in our own
            services.Remove<IModuleEnumerator>();
            services.Remove<IModuleLoaderService>();

            services.AddNew<XmlStreamDependentModuleEnumerator, IModuleEnumerator>();
            services.AddNew<DependentModuleLoaderService, IModuleLoaderService>();
            //services.AddNew<OpenFileModuleLoaderService, IModuleLoaderService>();

            services.AddOnDemand<ActionCatalogService, IActionCatalogService>();
            services.AddOnDemand<EntityTranslatorService, IEntityTranslatorService>();

            // Connexus or custom services (mapped from your VB list)
            //services.AddOnDemand<LocalizationManager, ILocalizationManager>();
            //services.AddOnDemand<ShowViewService, IShowViewService>();
            //services.AddNew<ProxyManager, IProxyManager>();
            //services.AddNew<PrintService, IPrintService>();
            //services.AddNew<ReportGeneratorService, IReportGeneratorService>();
            //services.AddNew<SecurityService, ISecurityService>();
            //services.AddNew<UserPreferencesService, IUserPreferencesService>();
            //services.AddNew<HL7ParserService, IHL7ParserService>();
            //services.AddNew<CentralDataHelperService, ICentralDataHelperService>();
            //services.AddNew<FaxServiceManager, IFaxServiceManager>();
            //services.AddNew<BusinessService, IBusinessService>();
            //services.AddNew<PharmanetService, IPharmanetService>();
            //services.AddNew<ScanService, IScanService>();
            //services.AddNew<RxToGoServiceManager, IRxToGoServiceManager>();
        }
    }


    

}
