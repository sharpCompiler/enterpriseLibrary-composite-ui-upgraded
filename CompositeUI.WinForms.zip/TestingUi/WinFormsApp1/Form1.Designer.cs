﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            deckWorkspace1 = new Microsoft.Practices.CompositeUI.WinForms.DeckWorkspace();
            SuspendLayout();
            // 
            // deckWorkspace1
            // 
            deckWorkspace1.Dock = DockStyle.Fill;
            deckWorkspace1.Location = new Point(0, 0);
            deckWorkspace1.Name = "deckWorkspace1";
            deckWorkspace1.Size = new Size(800, 450);
            deckWorkspace1.TabIndex = 0;
            deckWorkspace1.Text = "deckWorkspace1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(deckWorkspace1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);


        }

        #endregion

        private Microsoft.Practices.CompositeUI.WinForms.DeckWorkspace deckWorkspace1;
    }
}
