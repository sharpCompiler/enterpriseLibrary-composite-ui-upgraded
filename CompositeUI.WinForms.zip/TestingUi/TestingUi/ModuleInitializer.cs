﻿using Microsoft.Practices.CompositeUI;

namespace TestingUi;

public class ModuleInitializer : ModuleInit
{
    public override void Load()
    {
        base.Load();
    }
}