﻿using Microsoft.Practices.CompositeUI.SmartParts;

namespace TestingUi
{
    [SmartPart]
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }
    }
}
